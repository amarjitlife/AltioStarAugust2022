
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// _______________________________________________________

void playWithReferences() {
	// Ordinary free-standing reference:
	int y = 99;
	int & r = y;

	cout << endl;
	cout << "y = " << y << ", y = " << r << endl;

	int * yptr = &y;
	cout << "y = " << y << ", y = " << *yptr << endl;

	// When a reference is created, it must 
	// be initialized to a live object. 
	// However, you can also say:
	const int & q = 12;  // (1)
	// References are tied to someone else's storage:
	int x = 0;          // (2)
	int & a = x;         // (3)

	cout << "x = " << x << ", a = " << a << endl;
	a++;
	cout << "x = " << x << ", a = " << a << endl;
} ///:~

// _______________________________________________________

int* f(int* x) {
  (*x)++;
  return x; // Safe, x is outside this scope
}

int& g(int& x) {
  x++; // Same effect as in f()
  return x; // Safe, outside this scope
}

int& h() {
  int q;
//!  return q;  // Error
  static int x;
  return x; // Safe, x lives outside this scope
}

void ff(int &) {}
void gg(const int &) {}

// Reference To Int Type Data
void decrement(int & number ) { number++; }

// Reference To Pointer To Int Type Data
void increment(int * & i) { i++; }

void playWithReferencesArguments() {
  int a = 10;
  f(&a); // Ugly (but explicit)
  g(a);  // Clean (but hidden)
// ff(1); // Error
  gg(1);

  cout << endl;
  int number = 100;
  cout << "Number : " << number << endl;
  decrement( number );
  cout << "Number : " << number << endl;

  int * aptr = &a;
  cout << "aptr = " << aptr << endl;
  increment( aptr );
  cout << "aptr = " << aptr << endl;
} ///:~

// _______________________________________________________

struct Big {
  char buf[100];
  int i;
  long d;
};

Big bigFun(Big b) {
  cout << "Inside bigFun :" << b.i << endl;
  b.i = 100; // Do something to the argument
  cout << "Inside bigFun :" << b.i << endl;

  return b;
}

void playWithBig() {
	Big b1 = { "Gabbar Singh", 10, 999999 } ;
	Big b2;

	cout << endl;
	cout << b1.i << endl;
  	bigFun( b1 );
  	cout << b1.i << endl;
} ///:~

// _______________________________________________________

// Static Members Inside Class
//		Binded With Class Name
//		Are Accessed Using Class Name

// Non Static Members Inside Class
//		Binded With Object/Instance
//		Are Accessed Using Object/Instance Name

class Magical {
  // Intance/Object Private Members
  int instanceMemberPrivate;

  // Class/Type Members
  static int classMemberPrivate;
public:
   Magical() { 
  	 	instanceMemberPrivate = 111; 
   		instanceMember = 222; 
   }
  
  ~Magical() {
    	cout << "~Magical() Called" << endl;
  }

  // Intance/Object Members
  int instanceMember;
  void instanceFunction() { 
  	cout << "InstanceFunction Called : " << instanceMemberPrivate << endl; 
  }

  static int classMember;
  // Class/Type Members
  static void classFunction() {
  	cout << "classFunction Called : " << endl; 
  }

};

int Magical::classMember = 999;

void playWithClassStaticMembers() {
	Magical magic;
	cout << endl;
	cout << "Public Instance Member : " << magic.instanceMember << endl;
	magic.instanceFunction();

	cout << "Class Member : " << Magical::classMember << endl;
	Magical::classFunction();

	// Class/Type Members Are Also Accessible 
	//			Using Intances/Objects\
	// 			But Don't Use It
	cout << "Class Member : " << magic.classMember << endl;
	magic.classFunction();
} ///:~

// _______________________________________________________

class HowMany {
  static int objectCount;

public:
  HowMany() { 
	   objectCount++; 
       print("Constructor Called..."); 
	}

  static void print(const string& msg = "") {
    if(msg.size() != 0) cout << msg << ": ";
    cout << "objectCount = " << objectCount << endl;
  }

  ~HowMany() {
    objectCount--;
    print("Destructor Called...");
  }
};

int HowMany::objectCount = 0;

// File Member 
// Pass and Return BY VALUE:
HowMany doMagic( HowMany x ) {
  x.print("x Argument Inside doMagic()");
  return x;
}

void playWithHowMany() {
  HowMany h;
  cout << endl;
  HowMany::print("After h Object Construction...");
  HowMany h2 = doMagic( h );
  HowMany::print("After Call To doMagic()...");
}

// Function : playWithHowMany

// Constructor Called...: objectCount = 1
// After h Object Construction...: objectCount = 1
// x Argument Inside doMagic(): objectCount = 1
// Destructor Called...: objectCount = 0
// After Call To doMagic()...: objectCount = 0
// Destructor Called...: objectCount = -1
// Destructor Called...: objectCount = -2

// _______________________________________________________

int objectCount = 0;

class HowManyAgain {
  // static int objectCount;

public:
  HowManyAgain() { 
	   objectCount++; 
       print("Constructor Called..."); 
	}

  static void print(const string& msg = "") {
    if(msg.size() != 0) cout << msg << ": ";
    cout << "objectCount = " << objectCount << endl;
  }

  ~HowManyAgain() {
    objectCount--;
    print("Destructor Called...");
  }
};

// File Member 
// Pass and Return BY VALUE:
HowManyAgain doMagic( HowManyAgain x ) {
  x.print("x Argument Inside doMagic()");
  return x;
}

void playWithHowManyAgain() {
  HowManyAgain h;
  cout << endl;
  HowManyAgain::print("After h Object Construction...");
  HowManyAgain h2 = doMagic( h );
  HowManyAgain::print("After Call To doMagic()...");
}

// _______________________________________________________

class HowManyOnceAgain {
  string name; 				// Object identifier
  static int objectCount;

public:
  HowManyOnceAgain(const string& id = "") : name(id) {
    ++objectCount;
    print("HowManyOnceAgain() Called");
  }
  ~HowManyOnceAgain() {
    --objectCount;
    print("~HowManyOnceAgain() Called");
  }

  // The Copy Constructor:
  HowManyOnceAgain(const HowManyOnceAgain & h) : name(h.name) {
    name += " Copy";
    ++objectCount;
    print("HowManyOnceAgain(const HowManyOnceAgain &) Called");
  }

  void print(const string& msg = "") const {
    if( msg.size() != 0 ) 
      	cout << msg << endl;
    	cout << '\t' << name << ": " << "objectCount = " 
    		<< objectCount << endl;
  }
};

int HowManyOnceAgain::objectCount = 0;

// Pass and return BY VALUE:
HowManyOnceAgain doMagicOnceAgain(HowManyOnceAgain x) {
  x.print("x argument inside doMagicOnceAgain()");
  cout << "Returning from doMagicOnceAgain()" << endl;
  return x;
}

void playWithHowManyOnceAgain() {
  HowManyOnceAgain h("Gabbar Singh");
  
  cout << "Entering doMagicOnceAgain()" << endl;
  HowManyOnceAgain h2 = doMagicOnceAgain( h );
  h2.print("h2 after call to doMagicOnceAgain()");
  cout << "Call doMagicOnceAgain(), no return value" << endl;
  doMagicOnceAgain(h);
  cout << "After call to doMagicOnceAgain()" << endl;
} ///:~

// _______________________________________________________

class NoCC {
  int i;
  NoCC(const NoCC&); // No definition
public:
  NoCC(int ii = 0) : i(ii) {}
};

void f(NoCC);

void playWithNoCopyConstructor() {
  	NoCC n;
 	// f(n); 		 // Error: copy-constructor called
 	// NoCC n2 = n; // Error: copy-constructor called
 	// NoCC n3(n);  // Error: copy-constructor called
} ///:~

// _______________________________________________________

class Data {
public:  
  int a, b, c; 
  void print() const {
    cout << "a = " << a << ", b = " << b
         << ", c = " << c << endl;
  }
};

void playWithPointerToMember() {
  Data dataObject;
  Data *dataObjectPointer = &dataObject;
  int Data:: * pointerToDataMember = &Data::a;
  dataObjectPointer->*pointerToDataMember = 47;
  
  pointerToDataMember = &Data::b;
  dataObject.*pointerToDataMember = 48;
  
  pointerToDataMember = &Data::c;
  dataObjectPointer->*pointerToDataMember = 49;
  dataObjectPointer->print();
} ///:~

// _______________________________________________________

class Simple2 { 
public: 
  int f(float) const { return 1; }
};

int (Simple2::*fp)(float) const;

int (Simple2::*fp2)(float) const = &Simple2::f;

void playWithPointerToMemberFunction() {
  fp = &Simple2::f;
} ///:~

// _______________________________________________________

class Widget {
public:
  void f(int) const { cout << "Widget::f()\n"; }
  void g(int) const { cout << "Widget::g()\n"; }
  void h(int) const { cout << "Widget::h()\n"; }
  void i(int) const { cout << "Widget::i()\n"; }
};

void playWithPointerToWidgetMemberFunction() {
  Widget w;
  Widget* wp = &w;
  void (Widget::*pointerToMemberFunction)(int) const = &Widget::h;
  (w.*pointerToMemberFunction)(1);
  (wp->*pointerToMemberFunction)(2);
} ///:~


// _______________________________________________________

class WidgetAgain {
  void f(int) const { cout << "WidgetAgain::f()\n"; }
  void g(int) const { cout << "WidgetAgain::g()\n"; }
  void h(int) const { cout << "WidgetAgain::h()\n"; }
  void i(int) const { cout << "WidgetAgain::i()\n"; }
  enum { cnt = 4 };
  void (WidgetAgain::*fptr[cnt])(int) const;
public:
  WidgetAgain() {
    fptr[0] = &WidgetAgain::f; // Full spec required
    fptr[1] = &WidgetAgain::g;
    fptr[2] = &WidgetAgain::h;
    fptr[3] = &WidgetAgain::i;
  }
  void select(int i, int j) {
    if(i < 0 || i >= cnt) return;
    (this->*fptr[i])(j);
  }
  int count() { return cnt; }
}
void playWithPointerToWidgetAgainMemberFunction() {
  WidgetAgain w;
  for(int i = 0; i < w.count(); i++)
    w.select(i, 47);
} ///:~

// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________

int main( int argc, char * argv[] ) {
	cout << "\nFunction : playWithReferences";
	playWithReferences();

	cout << "\nFunction : playWithReferencesArguments";
	playWithReferencesArguments();

	cout << "\nFunction : playWithBig";
	playWithBig();

	cout << "\nFunction : playWithClassStaticMembers";
	playWithClassStaticMembers();

	cout << "\nFunction : playWithHowMany";
	playWithHowMany();

	cout << "\nFunction : playWithHowManyAgain";
	playWithHowManyAgain();

	cout << "\nFunction : playWithHowManyOnceAgain";
	playWithHowManyOnceAgain();

	cout << "\nFunction : playWithNoCopyConstructor";
	playWithNoCopyConstructor();

	cout << "\nFunction : playWithPointerToMember";
	playWithPointerToMember();

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	cout << "\nExiting From Main Function..." << endl;
	return 0;
}


