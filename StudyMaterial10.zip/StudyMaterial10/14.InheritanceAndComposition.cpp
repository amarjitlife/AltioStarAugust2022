
#include "require.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;
// _______________________________________________________

class X {
  int i;
public:
  X() { i = 0; }
  void set(int ii) { i = ii; }
  int read() const { return i; }
  int permute() { return i = i * 47; }
};

class Y {
  int i;
  X x; // Embedded Object Of Type X
public:
  Y() { i = 0; }
  int f(int ii) { 
  	i = ii; 
  	x.set(ii); 
  	return i;
  }
  int g() const { return i * x.read(); }
  int permute() { return x.permute(); }
};

void playWithObjectEmbedding() {
  Y y;
  cout << endl;
  cout << y.f(47) << endl;
  cout << y.permute() << endl;
} ///:~

// _______________________________________________________

class YY : public X {
  int i; // Different from X's i
public:
  YY() { i = 0; }
  int change() {
    i = permute(); // Different name call
    return i;
  }
  void set(int ii) {
    i = ii;
    X::set(ii); // Same-name function call
  }
};

void playWithInheritance() {
  cout << endl;
  cout << "sizeof(X) = " << sizeof(X) << endl;
  cout << "sizeof(YY) = " << sizeof(YY) << endl;
  YY D;
  D.change();
  // X function interface comes through:
  D.read();
  D.permute();
  // Redefined functions hide base versions:
  D.set(12);
} ///:~

// _______________________________________________________

class A {
  int i;
public:
  A(int ii) : i(ii) {}
  ~A() {}
  void f() const {}
};

class B {
  int i;
public:
  B(int ii) : i(ii) {}
  ~B() {}
  void f() const {}
};

class C : public B {
  A a; // Embedding Object Of Type A
public:
  C(int ii) : B(ii), a(ii) {}
  ~C() {} // Calls ~A() and ~B()
  void f() const {  // Redefinition
    a.f();
    B::f();
  }
};

void playWithBothInheritanceAndComposition() {
  C c(47);
} ///:~

// _______________________________________________________

#define CLASS(ID) class ID { \
public: \
  ID(int) { cout << #ID " constructor\n"; } \
  ~ID() {  cout << #ID " destructor\n"; } \
};

CLASS(Base1);
CLASS(Member1);
CLASS(Member2);
CLASS(Member3);
CLASS(Member4);

class Derived1 : public Base1 {
  Member1 m1;
  Member2 m2;
public:
  Derived1(int) : m2(1), m1(2), Base1(3) {
    cout << "Derived1 constructor\n";
  }
  ~Derived1() {
    cout << "Derived1 destructor\n";
  }
};

class Derived2 : public Derived1 {
  Member3 m3;
  Member4 m4;
public:
  Derived2() : m3(1), Derived1(2), m4(3) {
    cout << "Derived2 constructor\n";
  }
  ~Derived2() {
    cout << "Derived2 destructor\n";
  }
};

void playWithConstructorAndDestructorOrder() {
  Derived2 d2;
} ///:~

// _______________________________________________________

class Base {
public:
  int f() const { 
    cout << "Base::f()\n"; 
    return 1; 
  }
  int f(string) const { return 1; }
  void g() {}
};

class Derived11 : public Base {
public:
  void g() const {}
};

class Derived22 : public Base {
public:
  // Redefinition:
  int f() const { 
    cout << "Derived22::f()\n"; 
    return 2;
  }
};

class Derived33 : public Base {
public:
  // Change return type:
  void f() const { cout << "Derived33::f()\n"; }
};

class Derived44 : public Base {
public:
  // Change argument list:
  int f(int) const { 
    cout << "Derived44::f()\n"; 
    return 4; 
  }
};

void playWithInheritanceFunctions() {
  string s("hello");
  Derived11 d1;

  cout << endl;
  int x = d1.f();
  d1.f(s);
  Derived22 d2;
  x = d2.f();
// d2.f(s); // string version hidden
  Derived33 d3;
// x = d3.f(); // return int version hidden
  Derived44 d4;
// x = d4.f(); // f() version hidden
  x = d4.f(1);
} ///:~


// _______________________________________________________

class Stack {
  struct Link {
    void* data;
    Link* next;
    Link(void* dat, Link* nxt): 
      data(dat), next(nxt) {}
  }* head;
public:
  Stack() : head(0) {}
  ~Stack() {
    require(head == 0, "Stack not empty");
  }
  void push(void* dat) {
    head = new Link(dat, head);
  }
  void* peek() const { 
    return head ? head->data : 0;
  }
  void* pop() {
    if(head == 0) return 0;
    void* result = head->data;
    Link* oldHead = head;
    head = head->next;
    delete oldHead;
    return result;
  }
};

class StringStack : public Stack {
public:
  void push(string* str) {
    Stack::push(str);
  }
  string* peek() const {
    return (string*)Stack::peek();
  }
  string* pop() {
    return (string*)Stack::pop();
  }
  ~StringStack() {
    string* top = pop();
    while(top) {
      delete top;
      top = pop();
    }
  }
};

void playWithStringStack() {
  ifstream in("someFile.txt");
  assure(in, "someFile.txt");
  string line;
  StringStack textlines;
  while(getline(in, line))
    textlines.push(new string(line));
  string* s;

  cout << endl;
  while((s = textlines.pop()) != 0) { // No cast!
    cout << *s << endl;
    delete s;
  }
} ///:~

// _______________________________________________________

// Compiler Generated/Synthesized Methods
class GameBoard {
public:
  GameBoard() { cout << "GameBoard()\n"; }

  GameBoard(const GameBoard&) { 
    cout << "GameBoard(const GameBoard&)\n"; 
  }
  
  GameBoard& operator=(const GameBoard&) {
    cout << "GameBoard::operator=()\n";
    return *this;
  }
  ~GameBoard() { cout << "~GameBoard()\n"; }
};

class Game {
  GameBoard gb; // Composition
public:
  // Default GameBoard constructor called:
  Game() { cout << "Game()\n"; }

  // You must explicitly call the GameBoard
  // copy-constructor or the default constructor
  // is automatically called instead:
  Game(const Game& g) : gb(g.gb) { 
    cout << "Game(const Game&)\n"; 
  }

  Game(int) { cout << "Game(int)\n"; }

  Game& operator=(const Game& g) {
    // You must explicitly call the GameBoard
    // assignment operator or no assignment at 
    // all happens for gb!
    gb = g.gb;
    cout << "Game::operator=()\n";
    return *this;
  }

  class Other {}; // Nested class
  
  // Automatic type conversion:
  operator Other() const {
    cout << "Game::operator Other()\n";
    return Other();
  }
  ~Game() { cout << "~Game()\n"; }
};

class Chess : public Game {};

void f(Game::Other) {}

class Checkers : public Game {
public:

  // Default base-class constructor called:
  Checkers() { cout << "Checkers()\n"; }
 
  // You must explicitly call the base-class
  // copy constructor or the default constructor
  // will be automatically called instead:

  Checkers(const Checkers& c) : Game(c) {
    cout << "Checkers(const Checkers& c)\n";
  }

  Checkers& operator=(const Checkers& c) {
    // You must explicitly call the base-class
    // version of operator=() or no base-class
    // assignment will happen:
    Game::operator=(c);
    cout << "Checkers::operator=()\n";
    return *this;
  }
};

void playWithFunctionsSynthesizedByCompiler() {
  Chess d1;  // Default constructor
  Chess d2(d1); // Copy-constructor
//! Chess d3(1); // Error: no int constructor
  d1 = d2; // Operator= synthesized
  f(d1); // Type-conversion IS inherited
  Game::Other go;
//!  d1 = go; // Operator= not synthesized 
           // for differing types
  Checkers c1, c2(c1);
  c1 = c2;
} ///:~

// _______________________________________________________

class Engine {
public:
  void start() const {}
  void rev() const {}
  void stop() const {}
};

class Wheel {
public:
  void inflate(int psi) const {}
};

class Window {
public:
  void rollup() const {}
  void rolldown() const {}
};

class Door {
public:
  Window window;
  void open() const {}
  void close() const {}
};

class Car {
public:
  Engine engine;
  Wheel wheel[4];
  Door left, right; // 2-door
};

void playWithCar() {
  Car car;
  car.left.window.rollup();
  car.wheel[0].inflate(72);
} ///:~

// _______________________________________________________

class FName1 {
  ifstream file;
  string fileName;
  bool named;
public:
  FName1() : named(false) {}
  FName1(const string& fname) 
    : fileName(fname), file(fname.c_str()) {
    assure(file, fileName);
    named = true;
  }
  string name() const { return fileName; }
  void name(const string& newName) {
    if(named) return; // Don't overwrite
    fileName = newName;
    named = true;
  }
  operator ifstream&() { return file; }
};

void playWithFName1() {
  FName1 file("someFile.txt");
  cout << file.name() << endl;
  // Error: close() not a member:
//!  file.close();
} ///:~

// _______________________________________________________

class FName2 : public ifstream {
  string fileName;
  bool named;
public:
  FName2() : named(false) {}
  FName2(const string& fname)
    : ifstream(fname.c_str()), fileName(fname) {
    assure(*this, fileName);
    named = true;
  }
  string name() const { return fileName; }
  void name(const string& newName) {
    if(named) return; // Don't overwrite
    fileName = newName;
    named = true;
  }
};

void playWithFName2() {
  FName2 file("someFile.txt");
  assure(file, "someFile.txt");
  cout << "name: " << file.name() << endl;
  string s;
  getline(file, s); // These work too!
  file.seekg(-200, ios::end);
  file.close();
} ///:~

// _______________________________________________________

class Pet {
public:
  char eat() const { return 'a'; }
  int speak() const { return 2; }
  float sleep() const { return 3.0; }
  float sleep(int) const { return 4.0; }
};

class Goldfish : Pet { // Private inheritance
public:
  using Pet::eat;   // Name publicizes member
  using Pet::sleep; // Both members exposed
};

void playWithGoldfish() {
  Goldfish bob;
  bob.eat();
  bob.sleep();
  bob.sleep(1);
//! bob.speak();// Error: private member function
} ///:~

// _______________________________________________________

class Parent {
  int i;
  void doMagic() { cout << "Value Of i: " << i; }
protected:
  int read() const { return i; }
  void set(int ii) { i = ii; }
public:
  Parent(int ii = 0) : i(ii) {}
  int value(int m) const { return m*i; }
};

class Derived : public Parent {
  int j;
public:
  Derived(int jj = 0) : j(jj) {}
  void change(int x) { set(x); }
  // void doSomething() { doMagic(); }
}; 

void playWithPrivateAndProtectedMembers() {
  Derived d;
  d.change(10);
  // d.doSomething();
} ///:~

// _______________________________________________________

class Byte { 
  unsigned char b;
public:
  Byte(unsigned char bb = 0) : b(bb) {}
  // No side effects: const member function:
  const Byte
    operator+(const Byte& right) const {
    return Byte(b + right.b);
  }
  const Byte
    operator-(const Byte& right) const {
    return Byte(b - right.b);
  }
  const Byte
    operator*(const Byte& right) const {
    return Byte(b * right.b);
  }
  const Byte
    operator/(const Byte& right) const {
    require(right.b != 0, "divide by zero");
    return Byte(b / right.b);
  }
  const Byte
    operator%(const Byte& right) const {
    require(right.b != 0, "modulo by zero");
    return Byte(b % right.b);
  }
  const Byte
    operator^(const Byte& right) const {
    return Byte(b ^ right.b);
  }
  const Byte
    operator&(const Byte& right) const {
    return Byte(b & right.b);
  }
  const Byte
    operator|(const Byte& right) const {
    return Byte(b | right.b);
  }
  const Byte
    operator<<(const Byte& right) const {
    return Byte(b << right.b);
  }
  const Byte
    operator>>(const Byte& right) const {
    return Byte(b >> right.b);
  }
  // Assignments modify & return lvalue.
  // operator= can only be a member function:
  Byte& operator=(const Byte& right) {
    // Handle self-assignment:
    if(this == &right) return *this;
    b = right.b;
    return *this;
  }
  Byte& operator+=(const Byte& right) {
    if(this == &right) {/* self-assignment */}
    b += right.b;
    return *this;
  }
  Byte& operator-=(const Byte& right) {
    if(this == &right) {/* self-assignment */}
    b -= right.b;
    return *this;
  }
  Byte& operator*=(const Byte& right) {
    if(this == &right) {/* self-assignment */}
    b *= right.b;
    return *this;
  }
  Byte& operator/=(const Byte& right) {
    require(right.b != 0, "divide by zero");
    if(this == &right) {/* self-assignment */}
    b /= right.b;
    return *this;
  }
  Byte& operator%=(const Byte& right) {
    require(right.b != 0, "modulo by zero");
    if(this == &right) {/* self-assignment */}
    b %= right.b;
    return *this;
  }
  Byte& operator^=(const Byte& right) {
    if(this == &right) {/* self-assignment */}
    b ^= right.b;
    return *this;
  }
  Byte& operator&=(const Byte& right) {
    if(this == &right) {/* self-assignment */}
    b &= right.b;
    return *this;
  }
  Byte& operator|=(const Byte& right) {
    if(this == &right) {/* self-assignment */}
    b |= right.b;
    return *this;
  }
  Byte& operator>>=(const Byte& right) {
    if(this == &right) {/* self-assignment */}
    b >>= right.b;
    return *this;
  }
  Byte& operator<<=(const Byte& right) {
    if(this == &right) {/* self-assignment */}
    b <<= right.b;
    return *this;
  }
  // Conditional operators return true/false:
  int operator==(const Byte& right) const {
      return b == right.b;
  }
  int operator!=(const Byte& right) const {
      return b != right.b;
  }
  int operator<(const Byte& right) const {
      return b < right.b;
  }
  int operator>(const Byte& right) const {
      return b > right.b;
  }
  int operator<=(const Byte& right) const {
      return b <= right.b;
  }
  int operator>=(const Byte& right) const {
      return b >= right.b;
  }
  int operator&&(const Byte& right) const {
      return b && right.b;
  }
  int operator||(const Byte& right) const {
      return b || right.b;
  }
  // Write the contents to an ostream:
  void print(std::ostream& os) const {
    os << "0x" << std::hex << int(b) << std::dec;
  }
}; 


class Byte2 : public Byte {
public:
  // Constructors don't inherit:
  Byte2(unsigned char bb = 0) : Byte(bb) {}  
  // operator= does not inherit, but 
  // is synthesized for memberwise assignment.
  // However, only the SameType = SameType
  // operator= is synthesized, so you have to
  // make the others explicitly:
  Byte2& operator=(const Byte& right) {
    Byte::operator=(right);
    return *this;
  }

  Byte2& operator=(int i) { 
    Byte::operator=(i);
    return *this;
  }
};

// Similar test function as in C12:ByteTest.cpp:
void k(Byte2& b1, Byte2& b2) {
  b1 = b1 * b2 + b2 % b1;

  #define TRY2(OP) \
    cout << "b1 = "; b1.print(cout); \
    cout << ", b2 = "; b2.print(cout); \
    cout << ";  b1 " #OP " b2 produces "; \
    (b1 OP b2).print(cout); \
    cout << endl;

  b1 = 9; b2 = 47;
  TRY2(+) TRY2(-) TRY2(*) TRY2(/)
  TRY2(%) TRY2(^) TRY2(&) TRY2(|)
  TRY2(<<) TRY2(>>) TRY2(+=) TRY2(-=)
  TRY2(*=) TRY2(/=) TRY2(%=) TRY2(^=)
  TRY2(&=) TRY2(|=) TRY2(>>=) TRY2(<<=)
  TRY2(=) // Assignment operator

  // Conditionals:
  #define TRYC2(OP) \
    cout << "b1 = "; b1.print(cout); \
    cout << ", b2 = "; b2.print(cout); \
    cout << ";  b1 " #OP " b2 produces "; \
    cout << (b1 OP b2); \
    cout << endl;

  b1 = 9; b2 = 47;
  TRYC2(<) TRYC2(>) TRYC2(==) TRYC2(!=) TRYC2(<=)
  TRYC2(>=) TRYC2(&&) TRYC2(||)

  // Chained assignment:
  Byte2 b3 = 92;
  b1 = b2 = b3;
}

void playWithInheritanceAndOperators() {
  cout << "\nMember Functions:" << endl;
  Byte2 b1(47), b2(9);
  k(b1, b2);
} ///:~

// _______________________________________________________

enum note { middleC, Csharp, Cflat }; // Etc.

class Instrument {
public:
  void play(note) const { 
    cout << "\nInstrument play Called" << endl; 
  }
  void doSomething(){ 
    cout << "\nInstrument doSomething Called" << endl; 
  }
};
// WindInstrument objects are Instruments
// because they have the same interface:
class WindInstrument : public Instrument {
public:
  void play(note) const { 
    cout << "\nWindInstrument play Called" << endl; 
  }
  void doMagic(){ 
    cout << "\nWindInstrument doMagic Called" << endl; 
  }
};

void tune( Instrument& instrument ) {
  instrument.play(middleC);
  instrument.doSomething();
  // instrument.doMagic();
}

void playWithWindInstrument() {
  WindInstrument flute;
  flute.play(Csharp);
  flute.doMagic();
  flute.doSomething();

  // tune(flute); // Upcasting
  // Seeing Child Class Object 
  //    w.r.t. Parent Class Perceptive 
  Instrument& instrument = flute;
  instrument.play(middleC);
  // instrument.doMagic();
  instrument.doSomething();
} ///:~

// _______________________________________________________


class ParentAgain {
  int i;
public:
  ParentAgain(int ii) : i(ii) {
    cout << "ParentAgain(int ii)\n";
  }
  ParentAgain(const ParentAgain& b) : i(b.i) {
    cout << "ParentAgain(const ParentAgain&)\n";
  }
  ParentAgain() : i(0) { cout << "ParentAgain()\n"; }
  friend ostream&
    operator<<(ostream& os, const ParentAgain& b) {
    return os << "ParentAgain: " << b.i << endl;
  }
};

class Member {
  int i;
public:
  Member(int ii) : i(ii) {
    cout << "Member(int ii)\n";
  }
  Member(const Member& m) : i(m.i) {
    cout << "Member(const Member&)\n";
  }
  friend ostream&
    operator<<(ostream& os, const Member& m) {
    return os << "Member: " << m.i << endl;
  }
};

class Child : public ParentAgain {
  int i;
  Member m;
public:
  Child(int ii) : ParentAgain(ii), i(ii), m(ii) {
    cout << "Child(int ii)\n";
  }
  friend ostream&
    operator<<(ostream& os, const Child& c){
    return os << (ParentAgain&)c << c.m
              << "Child: " << c.i << endl;
  }
};

void playWithCopyConstructor() {
  Child c(2);
  cout << "calling copy-constructor: " << endl;
  Child c2 = c; // Calls copy-constructor
  cout << "values in c2:\n" << c2;
} ///:~

// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________


int main( int argc, char * argv[] ) {
	cout << "\nFunction : playWithObjectEmbedding";
	playWithObjectEmbedding();

	cout << "\nFunction : playWithInheritance";
	playWithInheritance();

	cout << "\nFunction : playWithBothInheritanceAndComposition";
	playWithBothInheritanceAndComposition();

	cout << "\nFunction : playWithConstructorAndDestructorOrder";
	playWithConstructorAndDestructorOrder();

	cout << "\nFunction : playWithInheritanceFunctions";
	playWithInheritanceFunctions();

	cout << "\nFunction : playWithStringStack";
  playWithStringStack();

  cout << "\nFunction : playWithFunctionsSynthesizedByCompiler";
  playWithFunctionsSynthesizedByCompiler();

  cout << "\nFunction : playWithCar";
  playWithCar();

  cout << "\nFunction : playWithFName1";
  playWithFName1();

	cout << "\nFunction : playWithFName2";
  playWithFName2();

	cout << "\nFunction : playWithGoldfish";
  playWithGoldfish();

	cout << "\nFunction : playWithPrivateAndProtectedMembers";
  playWithPrivateAndProtectedMembers();

	cout << "\nFunction : playWithInheritanceAndOperators";
  playWithInheritanceAndOperators();

	cout << "\nFunction : playWithWindInstrument";
  playWithWindInstrument();

	cout << "\nFunction : playWithCopyConstructor";
  playWithCopyConstructor();

  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";

	return 0;
}

