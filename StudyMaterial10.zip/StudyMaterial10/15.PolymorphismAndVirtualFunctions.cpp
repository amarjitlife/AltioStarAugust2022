#include "require.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// _______________________________________________________

enum note { middleC, Csharp, Cflat }; // Etc.

class Instrument0 {
public:
  virtual void play(note) const { 
    cout << "\nInstrument0 play Called" << endl; 
  }
  void doSomething(){ 
    cout << "\nInstrument0 doSomething Called" << endl; 
  }
};

// WindInstrument objects are Instruments
// because they have the same interface:
class WindInstrument0 : public Instrument0 {
public:
  void play(note) const { 
    cout << "\nWindInstrument0 play Called" << endl; 
  }
  void doMagic(){ 
    cout << "\nWindInstrument0 doMagic Called" << endl; 
  }
};

void tune( Instrument0& instrument ) {
  instrument.play(middleC);
  instrument.doSomething();
  // instrument.doMagic();
}

void playWithWindInstrument0() {
  WindInstrument0 flute;
  flute.play(Csharp);
  flute.doMagic();
  flute.doSomething();

  // tune(flute); // Upcasting
  // Seeing Child Class Object 
  //    w.r.t. Parent Class Perceptive 
  Instrument0& instrument = flute;
  instrument.play(middleC);
  // instrument.doMagic();
  instrument.doSomething();
} ///:~

// _______________________________________________________


class InstrumentOlder {
public:
  virtual void play(note) const {
    cout << "Instrument::play" << endl;
  }
  virtual string what() const {
    return "Instrument";
  }
  // Assume this will modify the object:
  virtual void adjust(int) {}
};

class Instrument {
public:
  // Pure Virtual Functions:
  virtual void play(note) const = 0;
  virtual string what() const = 0;
  // Assume this will modify the object:
  virtual void adjust(int) = 0;
};

class Wind : public Instrument {
public:
  // void play(note) const {
  //   cout << "Wind::play" << endl;
  // }
  string what() const { return "Wind"; }
  void adjust(int) {}
};

class Percussion : public Instrument {
public:
  void play(note) const {
    cout << "Percussion::play" << endl;
  }
  string what() const { return "Percussion"; }
  void adjust(int) {}
};

class Stringed : public Instrument {
public:
  void play(note) const {
    cout << "Stringed::play" << endl;
  }
  string what() const { return "Stringed"; }
  void adjust(int) {}
};

class Brass : public Wind {
public:
  void play(note) const {
    cout << "Brass::play" << endl;
  }
  string what() const { return "Brass"; }
};

class Woodwind : public Wind {
public:
  void play(note) const {
    cout << "Woodwind::play" << endl;
  }
  string what() const { return "Woodwind"; }
};

// Identical function from before:
void tune(Instrument& i) {
  // ...
  i.play(middleC);
}

// New function:
void f(Instrument& i) { i.adjust(1); }

// Upcasting during array initialization:
Instrument* A[] = {
  new Wind,
  new Percussion,
  new Stringed,
  new Brass,
};

void playWithInstruments() {
  Wind flute;
  Percussion drum;
  Stringed violin;
  Brass flugelhorn;
  Woodwind recorder;
  tune(flute);
  tune(drum);
  tune(violin);
  tune(flugelhorn);
  tune(recorder);
  f(flugelhorn);
} ///:~

// _______________________________________________________


class Pet {
public:
  virtual void speak() const = 0;
  virtual void eat() const = 0;
  // Inline pure virtual definitions illegal:
  //!  virtual void sleep() const = 0 {}
};

// OK, not defined inline
void Pet::eat() const {
  cout << "Pet::eat()" << endl;
}

void Pet::speak() const { 
  cout << "Pet::speak()" << endl;
}

class Dog : public Pet {
public:
  // Use the common Pet code:
  void speak() const { Pet::speak(); }
  void eat() const { Pet::eat(); }
};

void playWithPets() {
  Dog simba;  // Richard's dog
  simba.speak();
  simba.eat();
} ///:~

// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________

int main( int argc, char * argv[] ) {
  cout << "\nFunction : playWithWindInstrument0";
  playWithWindInstrument0();

  cout << "\nFunction : playWithInstruments";
  playWithInstruments();

  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";

	return 0;
}

