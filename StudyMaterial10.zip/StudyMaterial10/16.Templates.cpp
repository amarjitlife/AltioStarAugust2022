#include "require.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// _______________________________________________________

int fibonacci(int n);

int fibonacci(int n) {
  const int sz = 100;
  require(n < sz);
  static int f[sz]; // Initialized to zero
  f[0] = f[1] = 1;
  // Scan for unfilled array elements:
  int i;
  for(i = 0; i < sz; i++)
    if(f[i] == 0) break;
  while(i <= n) {
    f[i] = f[i-1] + f[i-2];
    i++;
  }
  return f[n];
} ///:~


class IntStack {
  enum { ssize = 100 };
  int stack[ssize];
  int top;
public:
  IntStack() : top(0) {}
  void push(int i) {
    require(top < ssize, "Too many push()es");
    stack[top++] = i;
  }
  int pop() {
    require(top > 0, "Too many pop()s");
    return stack[--top];
  }
};

class StringStack {
  enum { ssize = 100 };
  string stack[ssize];
  int top;
public:
  StringStack() : top(0) {}
  void push(string i) {
    require(top < ssize, "Too many push()es");
    stack[top++] = i;
  }
  string pop() {
    require(top > 0, "Too many pop()s");
    return stack[--top];
  }
};

class DoubleStack {
  enum { ssize = 100 };
  double stack[ssize];
  int top;
public:
  DoubleStack() : top(0) {}
  void push(double i) {
    require(top < ssize, "Too many push()es");
    stack[top++] = i;
  }
  double pop() {
    require(top > 0, "Too many pop()s");
    return stack[--top];
  }
};

void playWithStack() {
  IntStack is;
  // Add some Fibonacci numbers, for interest:
  for(int i = 0; i < 20; i++)
    is.push(fibonacci(i));
  // Pop & print them:
  cout << endl;
  for(int k = 0; k < 20; k++)
    cout << is.pop() << endl;

	// STORY GOES ON....
} ///:~

// _______________________________________________________
// _______________________________________________________

class Video {  };

class VideoStack {
  enum { ssize = 100 };
  Video stack[ssize];
  int top;
public:
  VideoStack() : top(0) {}
  void push(Video i) {
    require(top < ssize, "Too many push()es");
    stack[top++] = i;
  }
  Video pop() {
    require(top > 0, "Too many pop()s");
    return stack[--top];
  }
};

template<class T> class StackTemplate {
  enum { ssize = 100 };
  T stack[ssize];
  int top;
public:
  StackTemplate() : top(0) {}
  void push(const T& i) {
    require(top < ssize, "Too many push()es");
    stack[top++] = i;
  }
  T pop() {
    require(top > 0, "Too many pop()s");
    return stack[--top];
  }
  int size() { return top; }
};

void playWithStackTemplate() {
  StackTemplate<int> is;
  for(int i = 0; i < 20; i++)
    is.push(fibonacci(i));
  cout << endl;
  for(int k = 0; k < 20; k++)
    cout << is.pop() << endl;
  ifstream in("someFile.txt");
  assure(in, "someFile.txt");
  string line;

  StackTemplate<string> strings;
  while(getline(in, line))
    strings.push(line);
  cout << endl;
  while(strings.size() > 0)
    cout << strings.pop() << endl;
} ///:~

// _______________________________________________________

template<class T> class Array {
  enum { size = 100 };
  T A[size];
public:
  T& operator[](int index) {
    require(index >= 0 && index < size,
      "Index out of range");
    return A[index];
  }
};

void playWithGenericArray() {
  Array<int> ia;
  Array<float> fa;
  for(int i = 0; i < 20; i++) {
    ia[i] = i * i;
    fa[i] = float(i) * 1.414;
  }
  cout << endl;
  for(int j = 0; j < 20; j++)
    cout << j << ": " << ia[j]
         << ", " << fa[j] << endl;
} ///:~

// _______________________________________________________

template<class T> class Stack {
  struct Link {
    T* data;
    Link* next;
    Link(T* dat, Link* nxt): 
      data(dat), next(nxt) {}
  }* head;
public:
  Stack() : head(0) {}
  ~Stack(){ 
    while(head)
      delete pop();
  }
  void push(T* dat) {
    head = new Link(dat, head);
  }
  T* peek() const {
    return head ? head->data : 0; 
  }
  T* pop(){
    if(head == 0) return 0;
    T* result = head->data;
    Link* oldHead = head;
    head = head->next;
    delete oldHead;
    return result;
  }
};

class X {
public:
  virtual ~X() { cout << "~X " << endl; }
};

void playWithGenericStack( int argc, char * argv[] ) {
  requireArgs(argc, 1); // File name is argument
  ifstream in(argv[1]);
  assure(in, argv[1]);
  Stack<string> textlines;
  string line;
  // Read file and store lines in the Stack:
  while(getline(in, line))
    textlines.push(new string(line));
  // Pop some lines from the stack:
  string* s;
  for(int i = 0; i < 10; i++) {
    if((s = (string*)textlines.pop())==0) break;
    cout << *s << endl;
    delete s; 
  } // The destructor deletes the other strings.
  // Show that correct destruction happens:
  Stack<X> xx;
  for(int j = 0; j < 10; j++)
    xx.push(new X);
} ///:~

// _______________________________________________________

class Number {
  float f;
public:
  Number(float ff = 0.0f) : f(ff) {}
  Number& operator=(const Number& n) {
    f = n.f;
    return *this;
  }
  operator float() const { return f; }
  friend ostream&
    operator<<(ostream& os, const Number& x) {
      return os << x.f;
  }
};

template<class T, int size = 100> class ArrayAgain {
  T array[size];
public:
  T& operator[](int index) {
    require(index >= 0 && index < size,
      "Index out of range");
    return array[index];
  }
  int length() const { return size; }
};


template<class T, int size = 20> class Holder {
  ArrayAgain<T, size>* np;
public:
  Holder() : np(0) {}
  T& operator[](int i) {
    require(0 <= i && i < size);
    if(!np) np = new ArrayAgain<T, size>;
    return np->operator[](i);
  }
  int length() const { return size; }
  ~Holder() { delete np; }
};

void playWithGenericArrayAgainAndHolder() {
  Holder<Number> h;
  for(int i = 0; i < 20; i++)
    h[i] = i;
  for(int j = 0; j < 20; j++)
    cout << h[j] << endl;
} ///:~


// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________

int main( int argc, char * argv[] ) {
  cout << "\nFunction : playWithStack";
  playWithStack();

  cout << "\nFunction : playWithStackTemplate";
  playWithStackTemplate();

  cout << "\nFunction : playWithGenericArray";
  playWithGenericArray();

  cout << "\nFunction : playWithGenericStack";
  playWithGenericStack(argc, argv);

  cout << "\nFunction : playWithGenericArrayAgainAndHolder";
  playWithGenericArrayAgainAndHolder();

  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";
  // cout << "\nFunction : ";

	return 0;
}

