#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

void helloWorld() {
	printf("Hello, World! I am %d Today!", 18 );
}

// _______________________________________________________
// _______________________________________________________

// Bad Code
int sumOld( int x, int y ) {
	return x + y;
}

// Good Code
int sumGood( int a, int b ) {
	if ( ( b > 0 && a > ( INT_MAX - b ) ) || 
	     ( b < 0 && a < ( INT_MIN - b ) ) ) {
		printf("\nCan't Calculate Sum Of Given x And y Values\n");
		// exit( 1 );
	}
	else {
		int totalSum = 0;
		totalSum = a + b;
		return totalSum;
	}
	return 0;
}

// _______________________________________________________
// _______________________________________________________

void playWithSumBadCode() {
	int x = 100, y = 200;
	int result = 0;
	result = sumOld(x, y);
	printf("\nResult : %d", result );

	x = 2147483647;
	y = 2;
	result = sumOld(x, y);
	printf("\nBad Result : %d", result );

	x = -2147483648;
	y = -2;
	result = sumOld(x, y);
	printf("\nBad Result : %d", result );
}

void playWithSumGoodCode() {
	int x = 100, y = 200;
	int result = 0;
	result = sumGood(x, y);
	printf("\nResult : %d", result );

	x = 2147483647;
	y = 2;
	result = sumGood(x, y);

	x = -2147483648;
	y = -2;
	result = sumGood(x, y);
}

// Function : playWithSum
// Result : 300
// Result : -2147483647
// Result : 2147483646

// _______________________________________________________
// _______________________________________________________

void playWithArrays() {
	int a[5] = { 10, 20, 30, 40, 50 };

	printf("\nAddresses: %p %p", a, &a[0] );

	printf("\nArray Elements Are...");
	for( int i = 0 ; i < 5 ; i++ ) {

		// Accessing Array Elements Using Index Or Subscript 
		printf("\nArray Element At Index %d = %d", i, a[i]);
	}

	printf("\nArray Elements Addresses...");	
	for( int i = 0 ; i < 5 ; i++ ) {
		printf("\nStarting Address Of Array Element At Index %d : %p", 
			i, a + i );
	}

	printf("\nArray Elements Using Address Are...");
	for( int i = 0 ; i < 5 ; i++ ) {

		// Accessing Array Elements Using Pointers
		printf("\nArray Element At Index %d = %d", i, *(a + i) );
	}
}

// _______________________________________________________
// _______________________________________________________

struct Employee {
	int id;
	float salary;
	char name[20];	
};

void playWithTypeSizes() {
	char c = 'A';
	int i = 100;
	float f = 90.90;
	double d = 900.900;
	struct Employee adesh = { 101, 85000, "Adesh" };

	printf("\n Size : %ld", sizeof( c ) );
	printf("\n Size : %ld", sizeof( i ) );
	printf("\n Size : %ld", sizeof( f ) );
	printf("\n Size : %ld", sizeof( d ) );
	printf("\n Size : %ld", sizeof( adesh ) );

	char *cptr = &c;
	int *iptr = &i;
	float *fptr = &f;
	double *dptr = &d;
	struct Employee *eptr = &adesh;

	printf("\n Size : %ld", sizeof( cptr ) );
	printf("\n Size : %ld", sizeof( iptr ) );
	printf("\n Size : %ld", sizeof( fptr ) );
	printf("\n Size : %ld", sizeof( dptr ) );
	printf("\n Size : %ld", sizeof( eptr ) );	

	char gabbar[20] = "Gabbar Singh";
	char *gabbarAgain = "Gabbar Singh";
	char *gabbarOnceAgain = gabbar;

	printf("\n Size : %ld", sizeof( gabbar ) );	
	printf("\n Size : %ld", sizeof( gabbarAgain ) );	
	printf("\n Size : %ld", sizeof( gabbarOnceAgain ) );	
}

// _______________________________________________________
// _______________________________________________________

void playWithTypeValues() {
	char c = 'A';
	int i = 100;
	float f = 90.90;
	double d = 900.900;
	struct Employee adesh = { 101, 85000, "Adesh" };

	printf("\nValue : %c %d", c, c );
	printf("\nValue : %c %d", i, i );
	printf("\nValue : %f", f);
	printf("\nValue : %f", d);
	printf("\nValue : %d %f %s", adesh.id, adesh.salary, adesh.name );

	// ::::: NOTE NOTE NOTE NOTE ::::
	//_____________________________________________________________
	// Never Ever Downcast 
	//		Until and Unless You Are Sure About What You Are Doing
	// Upcasting Also Do WIth Due Diligence and Care!!!
	//_____________________________________________________________

	// BAD CODE
	f = (float) d;
	i = (int ) f;
	c = (char) i;

	printf("\nValue : %c %d", c, c );
	printf("\nValue : %c %d", i, i );
	printf("\nValue : %f", f);
	printf("\nValue : %f", d);
}

// _______________________________________________________
// _______________________________________________________

void playWithPointerTypeCasting() {
	double dd = 90.90;

	char 	*cptr;
	int 	*iptr;
	float 	*fptr;
	double 	*dptr;
	void 	*vptr;

	dptr = &dd;
	fptr = (float *) dptr;
	iptr = (int *) fptr;
	cptr = (char *) iptr;
	vptr = cptr;

	// printf("\nValue : %c %d", *vptr, *vptr );
	printf("\nValue : %c %d", *iptr, *iptr );
	printf("\nValue : %f", *fptr);
	printf("\nValue : %f", *dptr);

	printf("\n\nOnce Again...");
	printf("\nValue : %f", * (double *) dptr );
	printf("\nValue : %f", * (double *) fptr );
	printf("\nValue : %f", * (double *) iptr );
	printf("\nValue : %f", * (double *) cptr );
	printf("\nValue : %f", * (double *) vptr );
}

// _______________________________________________________
// _______________________________________________________

void playWithCharTypeSizes() {
	char gabbar[20] = "Gabbar Singh";
	char *gabbarAgain = "Gabbar Singh";
	char *gabbarOnceAgain = gabbar;

	printf("\n Value : %s", gabbar );	
	printf("\n Value : %s", gabbarAgain );	
	printf("\n Value : %s", gabbarOnceAgain );	

	printf("\n Size : %ld", sizeof( gabbar ) );	
	printf("\n Size : %ld", sizeof( gabbarAgain ) );	
	printf("\n Size : %ld", sizeof( gabbarOnceAgain ) );	
}


// _______________________________________________________
// _______________________________________________________

// Arrays Are Pass By Reference
void doChange1(int a[], int size) {
	for (int i = 0 ; i < size ; i++ ) {
		a[i] = 100;
	}
}

void doChange2(int *ptr, int size) {
	for (int i = 0 ; i < size ; i++ ) {
		*(ptr + i) = 200;
	}
}

void printArray(int a[], int size) {
	for (int i = 0 ; i < size ; i++ ) {
		printf( "\n%d", a[i] );
	}
}

void playWithArrayArguments() {
	int a[5] = { 10, 20, 30, 40, 50 };
	int size = 5;

	printArray( a, size );
	doChange1( a, size );
	printArray( a, size );
	doChange2( a, size );
	printArray( a, size );
}

// _______________________________________________________

void swapNumbers1( int a, int b) {
	int temp = a;
	a = b;
	b = temp;
}

void swapNumbers2( int *a, int *b) {
	int temp = *a;
	*a = *b;
	*b = temp;
}

void playWithSwapNumbers() {
	int a = 20, b =  50;

	printf("\nNumber a: %d and Number b: %d", a, b );
	swapNumbers1( a, b);
	printf("\nNumber a: %d and Number b: %d", a, b );
	swapNumbers2( &a, &b);
	printf("\nNumber a: %d and Number b: %d", a, b );
}

// _______________________________________________________
// _______________________________________________________

void sayHello() {
	printf("\nHello World!!!");
}

void sayGoodMorning() {
	printf("\nGood Morning!!!");	
}

void sayMessage( char message[] ) {
	printf("\nMessage : %s", message );	
}

int threeMultiple( int number ) {
	return number * 3;
}

void playWithFunctionPointers() {
	// Pointer To Function
	//		doSomething Is A Pointer To Function
	//		It Can Store Any Function 
	//			Having Retun Type void
	//			and Do Not Take Any Arguments

	void (*doSomething)();
	doSomething = sayHello;
	doSomething();

	doSomething = sayGoodMorning;
	doSomething();

	doSomething = sayMessage;
	doSomething("Do Good Work!!!");

	// warning: assignment to ‘void (*)()’ from incompatible 
	//   pointer type ‘int (*)(int)’
	// doSomething = threeMultiple;
	// Compilation Error : error: void value not ignored as it ought to be
	// int result = doSomething( 10 );	
	// printf("\n Result : %d", result);
}

// _______________________________________________________
// _______________________________________________________

// Function Type
// 		( int, int ) -> int
//		i.e. Function Taking 2 int Arguments And Returning int
int sum(int x, int y) { return x + y; }
int sub(int x, int y) { return x - y; }

// Function Type
// 		( int, int, int ) -> int
//		i.e. Function Taking 3 int Arguments And Returning int
int sum3(int x, int y, int z) { return x + y + z; }

void playWithFunctionPointersAgain() {
	// operation Is Function Pointer
	//		i.e. It's Pointer To Function
	//		It Can Store Only Functions Having 
	//			Function Type (int, int) -> int
	//		i.e. Function Taking 2 int Arguments And Returning int
	int result = 0;
	int (*operation)(int, int);

	operation = sum;
	result = operation( 500, 200 );
	printf("\n Result : %d", result);

	operation = sub;
	result = operation( 500, 200 );
	printf("\n Result : %d", result);

	// warning: assignment to ‘int (*)(int,  int)’ from 
	// incompatible pointer type ‘int (*)(int,  int,  int)’
	// operation = sum3;
	// Comiplation Error
	//  error: too many arguments to function ‘operation’
	// result = operation( 500, 200, 100 );
	// printf("\n Result : %d", result);
}

// _______________________________________________________

void playWithFunctionPointersOnceAgain() {
	int *( *something1 )(int *);

	int *( *something2[10] )(int *);
	int ** ( *something3 )(int *); 
	int function1(int *);

	int * function2(int *);
	int ( *function3 )(int *);
	int ( *function4(int *) );
	int * ( *function5(int *) );
}

// _______________________________________________________


// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________


// void main() {
int main() {
	printf("\n\nFunction : helloWorld");
	helloWorld();

	printf("\n\nFunction : playWithSumBadCode");
	playWithSumBadCode();

	printf("\n\nFunction : playWithSumGoodCode");
	playWithSumGoodCode();

	printf("\n\nFunction : playWithArrays");
	playWithArrays();

	printf("\n\nFunction : playWithTypeSizes");
	playWithTypeSizes();

	printf("\n\nFunction : playWithTypeValues");
	playWithTypeValues();

	printf("\n\nFunction : playWithPointerTypeCasting");
	playWithPointerTypeCasting();

	printf("\n\nFunction : playWithCharTypeSizes");
	playWithCharTypeSizes();

	printf("\n\nFunction : playWithArrayArguments");
	playWithArrayArguments();

	printf("\n\nFunction : playWithSwapNumbers");
	playWithSwapNumbers();

	printf("\n\nFunction : playWithFunctionPointers");
	playWithFunctionPointers();

	printf("\n\nFunction : playWithFunctionPointersAgain");
	playWithFunctionPointersAgain();

	printf("\n\nFunction : playWithFunctionPointersOnceAgain");
	playWithFunctionPointersOnceAgain();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");

	return 0;
}

