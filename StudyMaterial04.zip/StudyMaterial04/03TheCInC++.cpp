#include <iostream>

using namespace std;

// _______________________________________________________

// All Possible Combinations Of Basic Data Types,
// Specifiers, Pointers And References.

void f1(char c, int i, float f, double d);

void f2(short int si, long int li, long double ld);

void f3(unsigned char uc, unsigned int ui, 
	unsigned short int usi, unsigned long int uli);

void f4(char* cp, int* ip, float* fp, double* dp);

void f5(short int* sip, long int* lip, 
	long double* ldp);

void f6(unsigned char* ucp, unsigned int* uip, 
	unsigned short int* usip, 
	unsigned long int* ulip);

void f7(char & cr, int& ir, float& fr, double& dr);

void f8(short int& sir, long int& lir, 
	long double& ldr);

void f9(unsigned char& ucr, unsigned int& uir, 
	unsigned short int& usir, 
	unsigned long int& ulir);

// _______________________________________________________

// Command Line Arguments 
//		Inputted By User. It's Treated As string Type
//		Converting It To int Type
void playWithCommandLineArguments( int argc, char * argv[] ) {
	// argc Will Contain Count Of Command Line Arguments 
	//		Including Program Name
	// argv Will Contain Command Line Arguments
	//		As string Type

	// atoi() Function Will Convert string To int Type
	//		If Type Conversion Succeeds
	//			It Will Convert To int Type Value
	//		If Type Conversion Fails
	//			It Will Return 0 Value
	cout << "\nNumber Of Command Arguments: " << argc << endl;
	cout << "Command Line Arguments Passed Are..." << endl;
	for( int i = 0 ; i < argc ; i++ ) {
		cout << argv[i] << endl;
	}

	cout << "Command Line Arguments Converted To int Type: " << endl;
	for( int i = 0 ; i < argc ; i++ ) {
		cout << atoi( argv[i] ) << endl;
	}
} 

// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________

int main( int argc, char * argv[] ) {
	cout << "\nFunction : playWithCommandLineArguments";
	playWithCommandLineArguments(argc, argv);

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	return 0;
}

