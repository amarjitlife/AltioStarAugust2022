
_____________________________________________

DAY 01
_____________________________________________

	H1 : READING ASSIGNMENT

		Reading Chapters
			Chapter 01 : 1.1 To 1.8
			Chapter 02 : 2.1
			Chapter 03 : 3.1 To 3.5

		Reference:
			Operating Systems : Internals and Design Principles
			William Stalling

_____________________________________________

DAY 02
_____________________________________________

	H1 : READING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 01 : 1.1 To 1.8
			Chapter 02 : 2.1
			Chapter 03 : 3.1 To 3.5

		Reference:
			Operating Systems : Internals and Design Principles
			William Stalling

	H2 : READING ASSIGNMENT 

		Reading Chapters
			Chapter 02 : Making and Using Objects [ COMPLETE IT ]

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

	H3 : READING ASSIGNMENT 

		Reading Chapters
			Chapter 01 To Chapter 05
				Including Array and Pointers Chapter

		Reference:
			The C Programming Language, 2nd Edition
			Dennis Ritchie and Kernigham

	C1 : Write Following sum Function In C

		int sum( int x, int y ) {
			return x + y;
		}

		Following Even Don't Know Basic Syntax Knowledge 
			1. Chanti
			2. Kaveri
			3. Sai Tarun
			4. Manoj Kumar
			5. Sri Vidya
			6. Amisha

	C2 : Write Following sum Function In C

		It Should Return Valid Arithematic Sum
						OR
		Print Can't Calculate Sum Of Given x And y Values

		int sum( int x, int y ) {

		}

		Following Tried 2nd Attempt

			1. Adesh Kumar
			2. Kirti Rai 

		All Others Even Don't Know What They Are Doing?

_____________________________________________

DAY 03
_____________________________________________

	H1 : READING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 01 : 1.1 To 1.8
			Chapter 02 : 2.1
			Chapter 03 : 3.1 To 3.5

		Reference:
			Operating Systems : Internals and Design Principles
			William Stalling

	H2 : READING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 02 : Making and Using Objects [ COMPLETE IT ]

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

	H3 : READING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 01 To Chapter 05
				Including Array and Pointers Chapter

		Reference:
			The C Programming Language, 2nd Edition
			Dennis Ritchie and Kernigham


_____________________________________________

DAY 04
_____________________________________________

	_________________________________

	COMPULSORY CODING ASSIGNMENTS
	_________________________________

	C1: Coding Assignment
		Improve playWithWordsCount Code Example To 
		Count Frequency Of Words and Print Words and It's Frequency

	C2: Coding Assignment
		Improve playWithIntVector Code Example To 
		To Generate Tables From M To N Integer (Inclusive)

	C3: Coding Assignment [ In Class Room ]
		Take Input Dimension Of Square Matrix i.e. N and 
		Generate N x N Matrix Using Two Dimensional Array In C
		With Enteries Having Following Pattern...

		e.g. 6 x 6 Matrix Is As Follows...

			01 02 03 04 05 00
			02 03 04 05 00 01
			03 04 05 00 01 02
			04 05 00 01 02 03
			05 00 01 02 03 04
			00 01 02 03 04 05

	__________________________________________

	COMPULSORY CONCEPTS AND CODING ASSIGNMENTS
	__________________________________________


	H2 : READING AND CODING ASSIGNMENT [ COMPLETE IT ]

		Reading And Coding Assignments
			Chapter 02 : Making and Using Objects [ COMPLETE IT ]
			Chapter 03 : The C In C++ [ COMPLETE IT ]
		
			Read and Code All Examples In Chapter 02 and Chapter 03

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

	H3 : READING AND CODING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 01 To Chapter 05
				Including Array and Pointers Chapter

		Reference:
			The C Programming Language, 2nd Edition
			Dennis Ritchie and Kernigham

	___________________________

	LINUX REFERENCE MATERIAL
	___________________________

	R1: Linux Command and Concepts Learning
		Tutorial Book:
			First 130 Pages
			Linux Pocket Guide By Daniel J Barrett

		Reference Book:
			Linux in a Nutshell, 6th Edition
			by Ellen Siever, Stephen Figgins, Robert Love, Arnold Robbins

_____________________________________________

DAY 05
_____________________________________________




_____________________________________________

DAY 06
_____________________________________________




_____________________________________________

DAY 07
_____________________________________________




_____________________________________________

DAY 08
_____________________________________________




_____________________________________________

DAY 09
_____________________________________________




_____________________________________________

DAY 10
_____________________________________________




_____________________________________________

FUTURE WORK
_____________________________________________



_____________________________________________
_____________________________________________

