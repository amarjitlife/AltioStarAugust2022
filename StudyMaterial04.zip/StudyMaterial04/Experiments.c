#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

void helloWorld() {
	printf("Hello, World! I am %d Today!", 18 );
}

// _______________________________________________________
// _______________________________________________________

// Bad Code
int sumOld( int x, int y ) {
	return x + y;
}

// Good Code
int sum( int a, int b ) {
	if ( ( b > 0 && a > ( INT_MAX - b ) ) || 
	     ( b < 0 && a < ( INT_MIN - b ) ) ) {
		printf("\nCan't Calculate Sum Of Given x And y Values\n");
		// exit( 1 );
	}
	else {
		int totalSum = 0;
		totalSum = a + b;
		return totalSum;
	}
	return 0;
}

// _______________________________________________________
// _______________________________________________________

void playWithSumBadCode() {
	int x = 100, y = 200;
	int result = 0;
	result = sumOld(x, y);
	printf("\nResult : %d", result );

	x = 2147483647;
	y = 2;
	result = sumOld(x, y);
	printf("\nBad Result : %d", result );

	x = -2147483648;
	y = -2;
	result = sumOld(x, y);
	printf("\nBad Result : %d", result );
}

void playWithSumGoodCode() {
	int x = 100, y = 200;
	int result = 0;
	result = sum(x, y);
	printf("\nResult : %d", result );

	x = 2147483647;
	y = 2;
	result = sum(x, y);

	x = -2147483648;
	y = -2;
	result = sum(x, y);
}

// Function : playWithSum
// Result : 300
// Result : -2147483647
// Result : 2147483646

// _______________________________________________________
// _______________________________________________________

void playWithArrays() {
	int a[5] = { 10, 20, 30, 40, 50 };

	printf("\nAddresses: %p %p", a, &a[0] );

	printf("\nArray Elements Are...");
	for( int i = 0 ; i < 5 ; i++ ) {

		// Accessing Array Elements Using Index Or Subscript 
		printf("\nArray Element At Index %d = %d", i, a[i]);
	}

	printf("\nArray Elements Addresses...");	
	for( int i = 0 ; i < 5 ; i++ ) {
		printf("\nStarting Address Of Array Element At Index %d : %p", 
			i, a + i );
	}

	printf("\nArray Elements Using Address Are...");
	for( int i = 0 ; i < 5 ; i++ ) {

		// Accessing Array Elements Using Pointers
		printf("\nArray Element At Index %d = %d", i, *(a + i) );
	}
}

// _______________________________________________________
// _______________________________________________________

struct Employee {
	int id;
	float salary;
	char name[20];	
};

void playWithTypeSizes() {
	char c = 'A';
	int i = 100;
	float f = 90.90;
	double d = 900.900;
	struct Employee adesh = { 101, 85000, "Adesh" };

	printf("\n Size : %ld", sizeof( c ) );
	printf("\n Size : %ld", sizeof( i ) );
	printf("\n Size : %ld", sizeof( f ) );
	printf("\n Size : %ld", sizeof( d ) );
	printf("\n Size : %ld", sizeof( adesh ) );

	char *cptr = &c;
	int *iptr = &i;
	float *fptr = &f;
	double *dptr = &d;
	struct Employee *eptr = &adesh;

	printf("\n Size : %ld", sizeof( cptr ) );
	printf("\n Size : %ld", sizeof( iptr ) );
	printf("\n Size : %ld", sizeof( fptr ) );
	printf("\n Size : %ld", sizeof( dptr ) );
	printf("\n Size : %ld", sizeof( eptr ) );	

	char gabbar[20] = "Gabbar Singh";
	char *gabbarAgain = "Gabbar Singh";
	char *gabbarOnceAgain = gabbar;

	printf("\n Size : %ld", sizeof( gabbar ) );	
	printf("\n Size : %ld", sizeof( gabbarAgain ) );	
	printf("\n Size : %ld", sizeof( gabbarOnceAgain ) );	
}

// _______________________________________________________
// _______________________________________________________

void playWithTypeValues() {
	char c = 'A';
	int i = 100;
	float f = 90.90;
	double d = 900.900;
	struct Employee adesh = { 101, 85000, "Adesh" };

	printf("\nValue : %c %d", c, c );
	printf("\nValue : %c %d", i, i );
	printf("\nValue : %f", f);
	printf("\nValue : %f", d);
	printf("\nValue : %d %f %s", adesh.id, adesh.salary, adesh.name );

	// ::::: NOTE NOTE NOTE NOTE ::::
	//_____________________________________________________________
	// Never Ever Downcast 
	//		Until and Unless You Are Sure About What You Are Doing
	// Upcasting Also Do WIth Due Diligence and Care!!!
	//_____________________________________________________________

	// BAD CODE
	f = (float) d;
	i = (int ) f;
	c = (char) i;

	printf("\nValue : %c %d", c, c );
	printf("\nValue : %c %d", i, i );
	printf("\nValue : %f", f);
	printf("\nValue : %f", d);
}

// _______________________________________________________
// _______________________________________________________

void playWithPointerTypeCasting() {
	double dd = 90.90;

	char 	*cptr;
	int 	*iptr;
	float 	*fptr;
	double 	*dptr;
	void 	*vptr;

	dptr = &dd;
	fptr = (float *) dptr;
	iptr = (int *) fptr;
	cptr = (char *) iptr;
	vptr = cptr;

	// printf("\nValue : %c %d", *vptr, *vptr );
	printf("\nValue : %c %d", *iptr, *iptr );
	printf("\nValue : %f", *fptr);
	printf("\nValue : %f", *dptr);

	printf("\n\nOnce Again...");
	printf("\nValue : %f", * (double *) dptr );
	printf("\nValue : %f", * (double *) fptr );
	printf("\nValue : %f", * (double *) iptr );
	printf("\nValue : %f", * (double *) cptr );
	printf("\nValue : %f", * (double *) vptr );
}

// _______________________________________________________
// _______________________________________________________

void playWithCharTypeSizes() {
	char gabbar[20] = "Gabbar Singh";
	char *gabbarAgain = "Gabbar Singh";
	char *gabbarOnceAgain = gabbar;

	printf("\n Value : %s", gabbar );	
	printf("\n Value : %s", gabbarAgain );	
	printf("\n Value : %s", gabbarOnceAgain );	

	printf("\n Size : %ld", sizeof( gabbar ) );	
	printf("\n Size : %ld", sizeof( gabbarAgain ) );	
	printf("\n Size : %ld", sizeof( gabbarOnceAgain ) );	
}


// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________


// void main() {
int main() {
	printf("\n\nFunction : helloWorld");
	helloWorld();

	printf("\n\nFunction : playWithSumBadCode");
	playWithSumBadCode();

	printf("\n\nFunction : playWithSumGoodCode");
	playWithSumGoodCode();

	printf("\n\nFunction : playWithArrays");
	playWithArrays();

	printf("\n\nFunction : playWithTypeSizes");
	playWithTypeSizes();

	printf("\n\nFunction : playWithTypeValues");
	playWithTypeValues();

	printf("\n\nFunction : playWithPointerTypeCasting");
	playWithPointerTypeCasting();

	printf("\n\nFunction : playWithCharTypeSizes");
	playWithCharTypeSizes();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");

	return 0;
}

