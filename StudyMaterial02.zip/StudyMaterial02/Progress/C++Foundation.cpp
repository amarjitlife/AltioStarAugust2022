#include <string>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void helloWorld() {
	cout << "\nHello, World! I am " << 18 << " Today!" << endl;
}

void playWithDataConversion() {
	cout << endl;

	cout << "A Number In Decimal(Base 10): " << 15 << endl;
	cout << "A Number In Octal ( Base 8) : " << oct << 15 << endl;
	cout << "A Number In Hex ( Base 16) : " << hex << 15 << endl;

	cout << "Floating Point Number : " << 3.14159 << endl;
	// cout << "Non Printing Character (Esc) : " << char(27) << endl;

	// Concatinate The Strings
	cout << "Hello World!"
			"Ding Dong"
			"Ting Tong" << endl;
}

void playWithDataInput() {
	int number;

	cout << endl <<"Enter Number In Decimal: ";
	cin >> number;
	cout << "Value In Octal = 0" << oct << number << endl;
	cout << "Value In Octal = 0x" << hex << number << endl;
}

void playWithStrings() {
	string s1, s2;
	cout << s1 << s2 << endl;

	string s3 = "Hello, World!";
	string s4("Some String Value");

	cout << s3 << endl << s4 << endl;

	// String Concatenation
	s1 = s3 + " " + s4;
	s1 += " Ding Dong ";

	cout << s1 + s2 + "!" << endl;
}


void playWithStreams() {
	int lineCount = 1;
	ifstream in("someFile.txt");
	ofstream out("someFileAgain.txt");
	string line;

	cout << endl;
	while( getline(in, line) ) {
		cout << lineCount << "." << line << "\n";
		lineCount++;
	}

	ifstream inAgain("someFile.txt");
	lineCount = 1;
	while( getline(inAgain, line) ) {
		out << lineCount << "." << line << "\n";
		lineCount++;
	}

	ifstream inOnceAgain("someFile.txt");
	string s = "";
	lineCount = 1;
	while( getline(inOnceAgain, line) ) {
		s += lineCount + "." + line + "\n";
		lineCount++;
		// cout << "Check : " << line << endl;
	}

	cout << "\nFile Buffer" << endl;
	cout << s << endl;
}

void playWithStringVector() {
	vector<string> data;
	ifstream in("someFile.txt");

	string line;

	while( getline( in, line )) {
		data.push_back( line );
	}

	cout << endl;
	for( int i = 0 ; i < data.size() ; i++ ) {
		cout << i + 1 << " : " << data[i] << endl;
	}
}

// error: ‘::main’ must return ‘int’
//void main() {
int main() {
	cout << "\nFunction : helloWorld";
	helloWorld();

	cout << "\nFunction : playWithDataConversion";
	playWithDataConversion();

	// cout << "\nFunction : playWithDataInput";
	// playWithDataInput();

	cout << "\nFunction : playWithStrings";
	playWithStrings();

	cout << "\nFunction : playWithStreams";
	playWithStreams();

	cout << "\nFunction : playWithStringVector";
	playWithStringVector();

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	return 0;
}

