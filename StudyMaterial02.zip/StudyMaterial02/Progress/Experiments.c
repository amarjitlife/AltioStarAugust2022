#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

void helloWorld() {
	printf("Hello, World! I am %d Today!", 18 );
}

// Bad Code
int sumOld( int x, int y ) {
	return x + y;
}

// Good Code
int sum( int a, int b ) {
	if ( ( b > 0 && a > ( INT_MAX - b ) ) || 
	     ( b < 0 && a < ( INT_MIN - b ) ) ) {
		printf("\nCan't Calculate Sum Of Given x And y Values\n");
		// exit( 1 );
	}
	else {
		int totalSum = 0;
		totalSum = a + b;
		return totalSum;
	}
}

void playWithSumBadCode() {
	int x = 100, y = 200;
	int result = 0;
	result = sumOld(x, y);
	printf("\nResult : %d", result );

	x = 2147483647;
	y = 2;
	result = sumOld(x, y);
	printf("\nBad Result : %d", result );

	x = -2147483648;
	y = -2;
	result = sumOld(x, y);
	printf("\nBad Result : %d", result );
}

void playWithSumGoodCode() {
	int x = 100, y = 200;
	int result = 0;
	result = sum(x, y);
	printf("\nResult : %d", result );

	x = 2147483647;
	y = 2;
	result = sum(x, y);

	x = -2147483648;
	y = -2;
	result = sum(x, y);
}

// Function : playWithSum
// Result : 300
// Result : -2147483647
// Result : 2147483646

void main() {
	printf("\n\nFunction : helloWorld");
	helloWorld();

	printf("\n\nFunction : playWithSumBadCode");
	playWithSumBadCode();

	printf("\n\nFunction : playWithSumGoodCode");
	playWithSumGoodCode();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}

