
_____________________________________________

DAY 01
_____________________________________________

	H1 : READING ASSIGNMENT

		Reading Chapters
			Chapter 01 : 1.1 To 1.8
			Chapter 02 : 2.1
			Chapter 03 : 3.1 To 3.5

		Reference:
			Operating Systems : Internals and Design Principles
			William Stalling

_____________________________________________

DAY 02
_____________________________________________

	H1 : READING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 01 : 1.1 To 1.8
			Chapter 02 : 2.1
			Chapter 03 : 3.1 To 3.5

		Reference:
			Operating Systems : Internals and Design Principles
			William Stalling

	H2 : READING ASSIGNMENT 

		Reading Chapters
			Chapter 02 : Making and Using Objects [ COMPLETE IT ]

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel


	C1 : Write Following sum Function In C

		int sum( int x, int y ) {
			return x + y;
		}

		Following Even Don't Know Basic Syntax Knowledge 
			1. Chanti
			2. Kaveri
			3. Sai Tarun
			4. Manoj Kumar
			5. Sri Vidya
			6. Amisha

	C2 : Write Following sum Function In C

		It Should Return Valid Arithematic Sum
						OR
		Print Can't Calculate Sum Of Given x And y Values

		int sum( int x, int y ) {

		}

		Following Tried 2nd Attempt

			1. Adesh Kumar
			2. Kirti Rai 

		All Others Even Don't Know What They Are Doing?

_____________________________________________

DAY 03
_____________________________________________




_____________________________________________

DAY 04
_____________________________________________




_____________________________________________

DAY 05
_____________________________________________




_____________________________________________

DAY 06
_____________________________________________




_____________________________________________

DAY 07
_____________________________________________




_____________________________________________

DAY 08
_____________________________________________




_____________________________________________

DAY 09
_____________________________________________




_____________________________________________

DAY 10
_____________________________________________




_____________________________________________

FUTURE WORK
_____________________________________________



_____________________________________________
_____________________________________________

