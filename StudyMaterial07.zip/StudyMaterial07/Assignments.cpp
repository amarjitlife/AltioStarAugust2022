
_____________________________________________

DAY 01
_____________________________________________

	H1 : READING ASSIGNMENT

		Reading Chapters
			Chapter 01 : 1.1 To 1.8
			Chapter 02 : 2.1
			Chapter 03 : 3.1 To 3.5

		Reference:
			Operating Systems : Internals and Design Principles
			William Stalling

_____________________________________________

DAY 02
_____________________________________________

	H1 : READING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 01 : 1.1 To 1.8
			Chapter 02 : 2.1
			Chapter 03 : 3.1 To 3.5

		Reference:
			Operating Systems : Internals and Design Principles
			William Stalling

	H2 : READING ASSIGNMENT 

		Reading Chapters
			Chapter 02 : Making and Using Objects [ COMPLETE IT ]

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

	H3 : READING ASSIGNMENT 

		Reading Chapters
			Chapter 01 To Chapter 05
				Including Array and Pointers Chapter

		Reference:
			The C Programming Language, 2nd Edition
			Dennis Ritchie and Kernigham

	C1 : Write Following sum Function In C

		int sum( int x, int y ) {
			return x + y;
		}

		Following Even Don't Know Basic Syntax Knowledge 
			1. Chanti
			2. Kaveri
			3. Sai Tarun
			4. Manoj Kumar
			5. Sri Vidya
			6. Amisha

	C2 : Write Following sum Function In C

		It Should Return Valid Arithematic Sum
						OR
		Print Can't Calculate Sum Of Given x And y Values

		int sum( int x, int y ) {

		}

		Following Tried 2nd Attempt

			1. Adesh Kumar
			2. Kirti Rai 

		All Others Even Don't Know What They Are Doing?

_____________________________________________

DAY 02
_____________________________________________

	H1 : READING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 01 : 1.1 To 1.8
			Chapter 02 : 2.1
			Chapter 03 : 3.1 To 3.5

		Reference:
			Operating Systems : Internals and Design Principles
			William Stalling

	H2 : READING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 02 : Making and Using Objects [ COMPLETE IT ]

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

	H3 : READING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 01 To Chapter 05
				Including Array and Pointers Chapter

		Reference:
			The C Programming Language, 2nd Edition
			Dennis Ritchie and Kernigham


_____________________________________________

DAY 03
_____________________________________________

	_________________________________

	COMPULSORY CODING ASSIGNMENTS
	_________________________________

	C1: Coding Assignment
		Improve playWithWordsCount Code Example To 
		Count Frequency Of Words and Print Words and It's Frequency

		Following Participants Have Not Done!
			Sai Tarun
			Sreevidya
			Chanti
			Madhusudan
			Manojkumar
			Chandan
			Mridul
			Kaveri
			Vishal

		Following Participants Did Efforts To Write There Own Logic
			Adesh Kumar
			Yala Lakshmi 
			Vishal Dubey
			Amisha Kumari
			Sidharth Gupta

		Rest All Done!

	C2: Coding Assignment
		Improve playWithIntVector Code Example To 
		To Generate Tables From M To N Integer (Inclusive)

		Following Participants Are Not Able To Do Even Table Problem
			Sreevidya
			Chanti 

		Following Participants Seems Have Not There Own Solutions
			Bala Kumar
			Manoj Kumar

		Rest All Have Done It!

	C3: Coding Assignment [ In Class Room ]
		Take Input Dimension Of Square Matrix i.e. N and 
		Generate N x N Matrix Using Two Dimensional Array In C
		With Enteries Having Following Pattern...

		e.g. 6 x 6 Matrix Is As Follows...

			01 02 03 04 05 00
			02 03 04 05 00 01
			03 04 05 00 01 02
			04 05 00 01 02 03
			05 00 01 02 03 04
			00 01 02 03 04 05

		1st Attempt [ Given In Class Room ]
			Adesh Kumar Only Finished In 20 Minutes In Class Room
			Rest All Not Able To Do It 
				Even Given More Than One Hour In Class Room

			NOTE : Question Was Given At 4:10 PM Waited Till 5:20 PM.	
	
		2nd Attempt [ Given For Home ] 
			Not Done By Following Participants
				Akhila
				Chanti
				Mridul

			Following Participants Even Can't Comprehend Problem
				Sreevidya
					Directly Inputing Matrix Data 
				Vishal Dubey 
					Generating Pattern But Not Storing

			Following Participants Seems Have Not There Own Solutions
				Following Participants Have Similar Code Base
					Akhila
					Kaveri Gosala
					Bala Kumar

				Following Participants Have Similar Code Base
					Sai Tarun
					Chandan
					Manoj Kumar

		Following Participants Did Efforts To Write There Own Logic
				Madhusudan
				Sidharth Gupta

	__________________________________________

	COMPULSORY CONCEPTS AND CODING ASSIGNMENTS
	__________________________________________


	H2 : READING AND CODING ASSIGNMENT [ COMPLETE IT ]

		Reading And Coding Assignments
			Chapter 02 : Making and Using Objects [ COMPLETE IT ]
			Chapter 03 : The C In C++ [ COMPLETE IT ]
		
			Read and Code All Examples In Chapter 02 and Chapter 03

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

	H3 : READING AND CODING ASSIGNMENT [ COMPLETE IT ]

		Reading Chapters
			Chapter 01 To Chapter 05
				Including Array and Pointers Chapter

		Reference:
			The C Programming Language, 2nd Edition
			Dennis Ritchie and Kernigham

	___________________________

	LINUX REFERENCE MATERIAL
	___________________________

	R1: Linux Command and Concepts Learning
		Tutorial Book:
			First 130 Pages
			Linux Pocket Guide By Daniel J Barrett

		Reference Book:
			Linux in a Nutshell, 6th Edition
			by Ellen Siever, Stephen Figgins, Robert Love, Arnold Robbins

_____________________________________________

DAY 04
_____________________________________________

	_________________________________

	COMPULSORY CODING ASSIGNMENTS
	_________________________________

	C1: Coding Assignments
		1. Add Following Functionality To Link List Code
				Search Node
				Delete Node
				Move Node
		2. Simualte All Queues and Stack Operations 
			Using Link List
		3. Create Doubly Linked List
		4. Find If Cycle Exists In Linked List
		5. Create Circular Linked List

	C2: Coding Assignments
		Do All Above Code Using C++ Classes and Member Functions/Data

	__________________________________________

	COMPULSORY CONCEPTS AND CODING ASSIGNMENTS
	__________________________________________


	H1 : READING AND CODING ASSIGNMENT [ COMPLETE IT ]

		Reading And Coding Assignments
			Chapter 02 : Making and Using Objects [ COMPLETE IT ]
			Chapter 03 : The C In C++ 			  [ COMPLETE IT ]
			Chapter 04 : Data Abstraction 		  [ COMPLETE IT ]
		
			Read and Code All Examples 
				In Chapter 02 and Chapter 04

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

	H2 : READING AND CODING ASSIGNMENT [ COMPLETE IT ]

		Reading And Coding Assignments
			Chapter 01 To Chapter 06
				Chapter 05 : Pointers and Array
				Chapter 06 : Structures

			Read and Code All Examples 
				In Chapter 01 and Chapter 06

		Reference:
			The C Programming Language, 2nd Edition
			Dennis Ritchie and Kernigham

	_______________________________________________

	ALGORITHMS AND DATA STRUCTURES DESIGN REFERENCE
	_______________________________________________

	R1: Data Structure and Program Design In C++,
		By Robert L Kruse and Alexander J. Rybas

		Following 3 Participants Data Structure Assignments
			Adesh Kumar
			Yalla Lakshmi
			Amisha

		Following 2 Participants Need To Work On 
		Improving Algorithm Thinking 
			Vishal Dubey
			Bala Kumar 

		Chapter 02 : Introduction To Stack
		Chapter 03 : Queues
		Chapter 04 : Linked Stack and Queues

	R2: How To Solve It Using Computer, By R G Dromey
		Best Is Solve Whole Book 
			OR
		Atleast Till Searching Inclusive
			Chapter 01 To Chapter 04 
				and
			Chapter 05 : Algorithm 5.7 and Algorithm 5.8 

		Rest Of The Class Other Than Following 03 Participants
		Build Algorithmic Thinking First Than Solve Data Structure Problems
			Adesh Kumar
			Yalla Lakshmi
			Amisha

		NOTE : R2 Group Can Participate In R1 Group Problems
			   After Completing R2 Assignments
_____________________________________________

DAY 05
_____________________________________________

	__________________________________________

	COMPULSORY CONCEPTS AND CODING ASSIGNMENTS
	__________________________________________


	H1 : READING AND CODING ASSIGNMENT [ COMPLETE IT ]

		Reading And Coding Assignments
			Chapter 03 : The C In C++ 			  [ COMPLETE IT ]
			Chapter 04 : Data Abstraction 		  [ COMPLETE IT ]
		
			Read and Code All Examples 
				In Chapter 02 and Chapter 04

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

	H2 : READING AND CODING ASSIGNMENT [ COMPLETE IT ]

		Reading And Coding Assignments
			Chapter 01 To Chapter 06
				Chapter 05 : Pointers and Array
				Chapter 06 : Structures

			Read and Code All Examples 
				In Chapter 01 and Chapter 06

		Reference:
			The C Programming Language, 2nd Edition
			Dennis Ritchie and Kernigham
	_______________________________________________

_____________________________________________

DAY 06
_____________________________________________

	__________________________

	PROGRAMMING CHALLENGE!!!
	LEADER BOARD
	__________________________

	01. Amisha  		Q3$
	02. Adesh   		Q1+
	03. Kirti   		Q1*
	04. Ankush  		Q1&
	05. Bala Kumar 		Q1#
	06. Mridul  		Q1*
	07. Chandan 		Q1&
	08. Madhusudan      Q1#
	09.
	10.

	__________________________________________

	COMPULSORY CONCEPTS AND CODING ASSIGNMENTS
	__________________________________________

	H1 : READING AND CODING ASSIGNMENT [ COMPLETE IT ]

		Reading And Coding Assignments
			Chapter 04 : Data Abstraction   [ COMPLETE IT ]
			Chapter 05 : Hiding The Implementation		
			Read and Code All Examples 
				In Chapter 04 and Chapter 05

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

_____________________________________________

DAY 07
_____________________________________________

	__________________________________________

	COMPULSORY CONCEPTS AND CODING ASSIGNMENTS
	__________________________________________

	H1 : READING AND CODING ASSIGNMENT 				[ COMPLETE IT ]

		Reading And Coding Assignments
			Chapter 04 : Data Abstraction   		[ COMPLETE IT ]
			Chapter 05 : Hiding The Implementation	[ COMPLETE IT ]	

			Read and Code All Examples 
				In Chapter 04 and Chapter 05

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

	H2 : CODE EXERCISES FROM FOLLOWING     			[ COMPLETE IT ]

		Reading And Coding Assignments
			Chapter 04 : Data Abstraction   		[ COMPLETE IT ]
			Chapter 05 : Hiding The Implementation	[ COMPLETE IT ]	

			Code First 10 Excercises 
				In The End Of Chapter 04 and Chapter 05

		Reference:
			Thinking In C++, Volume I, 2nd Edition
			Bruce Eckel

_____________________________________________

DAY 08
_____________________________________________




_____________________________________________

DAY 09
_____________________________________________




_____________________________________________

DAY 10
_____________________________________________




_____________________________________________

FUTURE WORK
_____________________________________________



_____________________________________________
_____________________________________________

