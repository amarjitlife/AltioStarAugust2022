
package learnKotlin;

class Outer {
	var specialRecipe : Int = 99

	inner class Nested {
		var regularRecipe : Int = 999
	
		fun getValue() : Int {
			println("Value regularRecipe : $regularRecipe")
			println("Value specialRecipe : $specialRecipe")
			return regularRecipe
		}
	}

	fun getValue() : Int {
		println("Value specialRecipe : $specialRecipe")
		return specialRecipe
	}	
}

fun playWithNestedClasses() {
	var outer = Outer()
	// var nested = Outer.Nested()
	var nested = outer.Nested()

	outer.getValue()
	nested.getValue()
}

fun main() {
	playWithNestedClasses();
}

