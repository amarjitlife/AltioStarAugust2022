
#include "require.h"
#include <fstream>
#include <string>
#include <iostream>
#include <cassert>
using namespace std;

// _______________________________________________________

class Stash {
	int size;      // Size of each space
	int quantity;  // Number of storage spaces
	int next;      // Next empty space
	// Dynamically allocated array of bytes:
	unsigned char* storage;
	void inflate(int increase);
public:
	Stash(int size);
	~Stash();
	int add(void* element);
	void* fetch(int index);
	int count();
};


const int increment = 100;

Stash::Stash(int sz) {
	size = sz;
	quantity = 0;
	storage = 0;
	next = 0;
}

int Stash::add(void* element) {
	if(next >= quantity) // Enough space left?
	inflate(increment);
	// Copy element into storage,
	// starting at next empty space:
	int startBytes = next * size;
	unsigned char* e = (unsigned char*)element;
	for(int i = 0; i < size; i++)
	storage[startBytes + i] = e[i];
	next++;
	return(next - 1); // Index number
}

void* Stash::fetch(int index) {
	require(0 <= index, "Stash::fetch (-)index");
	if(index >= next)
	return 0; // To indicate the end
	// Produce pointer to desired element:
	return &(storage[index * size]);
}

int Stash::count() {
	return next; // Number of elements in CStash
}

void Stash::inflate(int increase) {
	require(increase > 0, 
	"Stash::inflate zero or negative increase");
	int newQuantity = quantity + increase;
	int newBytes = newQuantity * size;
	int oldBytes = quantity * size;
	unsigned char* b = new unsigned char[newBytes];
	for(int i = 0; i < oldBytes; i++)
	b[i] = storage[i]; // Copy old to new
	delete [](storage); // Old storage
	storage = b; // Point to new memory
	quantity = newQuantity;
}

Stash::~Stash() {
	if(storage != 0) {
		cout << "freeing storage" << endl;
		delete []storage;
	}
} ///:~


void playWithStash() {
	Stash intStash(sizeof(int));
	for(int i = 0; i < 100; i++)
	intStash.add(&i);
	for(int j = 0; j < intStash.count(); j++)
	cout << "intStash.fetch(" << j << ") = "
		 << *(int*)intStash.fetch(j)
		 << endl;
	const int bufsize = 80;
	Stash stringStash(sizeof(char) * bufsize);
	ifstream in("someFile.txt");
	assure(in, "someFile.txt");
	string line;
	while(getline(in, line))
	stringStash.add((char*)line.c_str());
	int k = 0;
	char* cp;
	while((cp = (char*)stringStash.fetch(k++))!=0)
	cout << "stringStash.fetch(" << k << ") = "
		 << cp << endl;
} ///:~


// _______________________________________________________

class Stack {
	struct Link {
		void* data;
		Link* next;
		Link(void* dat, Link* nxt);
		~Link();
	}* head;
public:
	Stack();
	~Stack();
	void push(void* dat);
	void* peek();
	void* pop();
};

Stack::Link::Link(void* dat, Link* nxt) {
	data = dat;
	next = nxt;
}

Stack::Link::~Link() { }

Stack::Stack() { head = 0; }

void Stack::push(void* dat) {
	head = new Link(dat,head);
}

void* Stack::peek() { 
	require(head != 0, "Stack empty");
	return head->data; 
}

void* Stack::pop() {
	if(head == 0) return 0;
	void* result = head->data;
	Link* oldHead = head;
	head = head->next;
	delete oldHead;
	return result;
}

Stack::~Stack() {
	require(head == 0, "Stack not empty");
} ///:~

void playWithStack(int argc, char* argv[]) {
	requireArgs(argc, 1); // File name is argument
	ifstream in(argv[1]);
	assure(in, argv[1]);
	Stack textlines;
	string line;
	// Read file and store lines in the stack:
	while(getline(in, line))
	textlines.push(new string(line));
	// Pop the lines from the stack and print them:
	string* s;
	while((s = (string*)textlines.pop()) != 0) {
	cout << *s << endl;
	delete s; 
	}
} ///:~

// _______________________________________________________

class Z {
	int i, j;
public:
	Z(int ii, int jj);
	void print();
};

Z::Z(int ii, int jj) {
	i = ii;
	j = jj;
}

void Z::print() {
	cout << "i = " << i << ", j = " << j << endl;
}

void playWithConstructors() {
	Z zz[] = { Z(1, 2), Z{3, 4}, Z(10, 20) };

	cout << endl;
	for ( int i = 0 ; i < sizeof zz / sizeof *zz ; i++ ) {
		zz[i].print();
	}
}


// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________

int main( int argc, char * argv[] ) {
	cout << "\nFunction : playWithStash";
	playWithStash();

	cout << "\nFunction : playWithStack";
	playWithStack(argc, argv);

	cout << "\nFunction : playWithConstructors";
	playWithConstructors();

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	return 0;
}

