
#include "require.h"
#include <iostream>

using namespace std;
// _______________________________________________________

class X {
  int i;
public:
  X() { i = 0; }
  void set(int ii) { i = ii; }
  int read() const { return i; }
  int permute() { return i = i * 47; }
};

class Y {
  int i;
  X x; // Embedded Object Of Type X
public:
  Y() { i = 0; }
  int f(int ii) { 
  	i = ii; 
  	x.set(ii); 
  	return i;
  }
  int g() const { return i * x.read(); }
  int permute() { return x.permute(); }
};

void playWithObjectEmbedding() {
  Y y;
  cout << endl;
  cout << y.f(47) << endl;
  cout << y.permute() << endl;
} ///:~

// _______________________________________________________

class YY : public X {
  int i; // Different from X's i
public:
  YY() { i = 0; }
  int change() {
    i = permute(); // Different name call
    return i;
  }
  void set(int ii) {
    i = ii;
    X::set(ii); // Same-name function call
  }
};

void playWithInheritance() {
  cout << endl;
  cout << "sizeof(X) = " << sizeof(X) << endl;
  cout << "sizeof(YY) = " << sizeof(YY) << endl;
  YY D;
  D.change();
  // X function interface comes through:
  D.read();
  D.permute();
  // Redefined functions hide base versions:
  D.set(12);
} ///:~

// _______________________________________________________

class A {
  int i;
public:
  A(int ii) : i(ii) {}
  ~A() {}
  void f() const {}
};

class B {
  int i;
public:
  B(int ii) : i(ii) {}
  ~B() {}
  void f() const {}
};

class C : public B {
  A a; // Embedding Object Of Type A
public:
  C(int ii) : B(ii), a(ii) {}
  ~C() {} // Calls ~A() and ~B()
  void f() const {  // Redefinition
    a.f();
    B::f();
  }
};

void playWithBothInheritanceAndComposition() {
  C c(47);
} ///:~

// _______________________________________________________

#define CLASS(ID) class ID { \
public: \
  ID(int) { cout << #ID " constructor\n"; } \
  ~ID() {  cout << #ID " destructor\n"; } \
};

CLASS(Base1);
CLASS(Member1);
CLASS(Member2);
CLASS(Member3);
CLASS(Member4);

class Derived1 : public Base1 {
  Member1 m1;
  Member2 m2;
public:
  Derived1(int) : m2(1), m1(2), Base1(3) {
    cout << "Derived1 constructor\n";
  }
  ~Derived1() {
    cout << "Derived1 destructor\n";
  }
};

class Derived2 : public Derived1 {
  Member3 m3;
  Member4 m4;
public:
  Derived2() : m3(1), Derived1(2), m4(3) {
    cout << "Derived2 constructor\n";
  }
  ~Derived2() {
    cout << "Derived2 destructor\n";
  }
};

void playWithConstructorAndDestructorOrder() {
  Derived2 d2;
} ///:~

// _______________________________________________________

class Base {
public:
  int f() const { 
    cout << "Base::f()\n"; 
    return 1; 
  }
  int f(string) const { return 1; }
  void g() {}
};

class Derived11 : public Base {
public:
  void g() const {}
};

class Derived22 : public Base {
public:
  // Redefinition:
  int f() const { 
    cout << "Derived22::f()\n"; 
    return 2;
  }
};

class Derived33 : public Base {
public:
  // Change return type:
  void f() const { cout << "Derived33::f()\n"; }
};

class Derived44 : public Base {
public:
  // Change argument list:
  int f(int) const { 
    cout << "Derived44::f()\n"; 
    return 4; 
  }
};

void playWithInheritanceFunctions() {
  string s("hello");
  Derived11 d1;

  cout << endl;
  int x = d1.f();
  d1.f(s);
  Derived22 d2;
  x = d2.f();
// d2.f(s); // string version hidden
  Derived33 d3;
// x = d3.f(); // return int version hidden
  Derived44 d4;
// x = d4.f(); // f() version hidden
  x = d4.f(1);
} ///:~


// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________

int main( int argc, char * argv[] ) {
	cout << "\nFunction : playWithObjectEmbedding";
	playWithObjectEmbedding();

	cout << "\nFunction : playWithInheritance";
	playWithInheritance();

	cout << "\nFunction : playWithBothInheritanceAndComposition";
	playWithBothInheritanceAndComposition();

	cout << "\nFunction : playWithConstructorAndDestructorOrder";
	playWithConstructorAndDestructorOrder();

	cout << "\nFunction : playWithInheritanceFunctions";
	playWithInheritanceFunctions();

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	return 0;
}

