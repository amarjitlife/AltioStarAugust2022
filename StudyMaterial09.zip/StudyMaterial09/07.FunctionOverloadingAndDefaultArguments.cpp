#include "require.h"
#include <fstream>
#include <string>
#include <iostream>
#include <cassert>
using namespace std;

// _______________________________________________________

void f1( int x ) {
	cout << "Function f1( int ) Called..." << endl;
}

void f1( long x ) {
	cout << "Function f1( long ) Called..." << endl;
}

void f1( int x, int y ) {
	cout << "Function f1( int, int ) Called..." << endl;
}

void f1( double ) {
	cout << "Function f1( double ) Called..." << endl;
}

void f1( float x ) {
	cout << "Function f1( float ) Called..." << endl;
}

void playWithFunctions() {
	cout << endl;

	f1( 10 );
	// f1( 10, 100 );

	f1( (int) 10.90 );
	f1( (float) 10.90 );

	f1( 100.900 );
}

// _______________________________________________________

class Calculator {

public:
	int addition(int x, int y) { return x + y; }
	int addition(int x, int y, int z) { return x + y + z; }

	double addition(double x, double y) { return x + y; }
	double addition(double x, double y, double z) { return x + y + z; }

	int substraction(int x, int y) { return x - y; }
	int substraction(int x, int y, int z) { return x - y - z; }

	double substraction(double x, double y) { return x - y; }
	double substraction(double x, double y, double z) { return x - y - z; }
};

void playWithCalculator() {
	Calculator calc;

	cout << calc.addition( 10, 20 ) << endl;
	cout << calc.addition( 10, 20, 30 ) << endl;
	cout << calc.addition( 10.1, 20.2 ) << endl;
	cout << calc.addition( 10.1, 20.2, 30.3 ) << endl;

	cout << calc.substraction( 10, 20 ) << endl;
	cout << calc.substraction( 10, 20, 30 ) << endl;
	cout << calc.substraction( 10.1, 20.2 ) << endl;
	cout << calc.substraction( 10.1, 20.2, 30.3 ) << endl;
}


// _______________________________________________________

class Stash {
  int size;      // Size of each space
  int quantity;  // Number of storage spaces
  int next;      // Next empty space
  // Dynamically allocated array of bytes:
  unsigned char* storage;
  void inflate(int increase);
public:
  
  // OVERLOADED CONSTRUCTORS
  Stash(int size); // Zero quantity
  Stash(int size, int initQuantity);

  ~Stash();
  int add(void* element);
  void* fetch(int index);
  int count();
};

const int increment = 100;

Stash::Stash(int sz) {
  size = sz;
  quantity = 0;
  next = 0;
  storage = 0;
}

Stash::Stash(int sz, int initQuantity) {
  size = sz;
  quantity = 0;
  next = 0;
  storage = 0;
  inflate(initQuantity);
}

Stash::~Stash() {
  if(storage != 0) {
    cout << "freeing storage" << endl;
    delete []storage;
  }
}

int Stash::add(void* element) {
  if(next >= quantity) // Enough space left?
    inflate(increment);
  // Copy element into storage,
  // starting at next empty space:
  int startBytes = next * size;
  unsigned char* e = (unsigned char*)element;
  for(int i = 0; i < size; i++)
    storage[startBytes + i] = e[i];
  next++;
  return(next - 1); // Index number
}

void* Stash::fetch(int index) {
  require(0 <= index, "Stash::fetch (-)index");
  if(index >= next)
    return 0; // To indicate the end
  // Produce pointer to desired element:
  return &(storage[index * size]);
}

int Stash::count() {
  return next; // Number of elements in CStash
}

void Stash::inflate(int increase) {
  assert(increase >= 0);
  if(increase == 0) return;
  int newQuantity = quantity + increase;
  int newBytes = newQuantity * size;
  int oldBytes = quantity * size;
  unsigned char* b = new unsigned char[newBytes];
  for(int i = 0; i < oldBytes; i++)
    b[i] = storage[i]; // Copy old to new
  delete [](storage); // Release old storage
  storage = b; // Point to new memory
  quantity = newQuantity; // Adjust the size
} ///:~

void playWithStash() {
  Stash intStash(sizeof(int));
  for(int i = 0; i < 100; i++)
    intStash.add(&i);
  for(int j = 0; j < intStash.count(); j++)
    cout << "intStash.fetch(" << j << ") = "
         << *(int*)intStash.fetch(j)
         << endl;
  const int bufsize = 80;
  Stash stringStash(sizeof(char) * bufsize, 100);
  ifstream in("someFile.txt");
  assure(in, "someFile.txt");
  string line;
  while(getline(in, line))
    stringStash.add((char*)line.c_str());
  int k = 0;
  char* cp;
  while((cp = (char*)stringStash.fetch(k++))!=0)
    cout << "stringStash.fetch(" << k << ") = "
         << cp << endl;
} ///:~


// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________


int main( int argc, char * argv[] ) {
	cout << "\nFunction : playWithFunctions";
	playWithFunctions();

	cout << "\nFunction : playWithCalculator";
	playWithCalculator();

	cout << "\nFunction : playWithStash";
	playWithStash();

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	return 0;
}

