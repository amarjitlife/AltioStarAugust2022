
#include "require.h"
#include <iostream>
// #include <fstream>
// #include <string>
// #include <cassert>

using namespace std;

// _______________________________________________________
// _______________________________________________________

struct SA {
private:
	int i, j, k;
public:
	int f();
	void g();
};

int SA::f() {
	return i + j + k;
}

void SA::g() {
	i = j = k = 0;
}

class CA {
private:
	int i, j, k;
public:
	int f();
	void g();
};

int CA::f() {
	return i + j + k;
}

void CA::g() {
	i = j = k = 0;
}

void playWithClassAndStructure() {
// Here Write Your Code...
}

// _______________________________________________________

class BB {
private:
	char j;
	float f;
public:
	int i;
	void func();
};

void BB::func() {
	i = 0;
	j = 'A';
	f = 0.0;
}

void playWithClassBB() {
	BB b;

	b.i = 10;
	// error: ‘char BB::j’ is private within this context
	// b.j = 'B';
	// error: ‘char BB::f’ is private within this context
	// b.f = 90.90;
}
// _______________________________________________________

struct AA {
	int i;
	char j;
	float f;
	void func();
};
void AA::func() {}

struct SB {
public:
	int i;
	char j;
	float f;
	void func();
};
void SB::func() {}  

void playWithStructuresAAandSB() {
	AA a; SB b;
	a.i = b.i = 1;
	a.j = b.j = 'c';
	a.f = b.f = 3.14159;
	a.func();
	b.func();
} ///:~

// _______________________________________________________

// Declaration Of Class X 
class X;

// Definition Of Class Y With One Menber Function
class Y {
public:
	void f( X * );
};

// Defination Of Class X
// 		Fiends Can Acess All Members Of Target Class
//		Including Private Members

// CODING GUIDELINES:
//		Friend Functionality We Should Not Use
//		Because It Breaks Encapsulation
//		It Is Used In Rarest Rare Scenarios 

class X {
private:
	int i;
public:
	void initialize();
	friend void g(X, int); 		// Global Function Is Friend
	friend void gg(X *, int); 	// Global Function Is Friend
	friend void Y::f( X * );  	// Member Fuction From Y Is Friend
	friend class Z; 			// Entire Class Is Friend
	friend void h(); 			// Global Function Is Friend
};

void X::initialize() { 	i = 10; }
//  error: ‘int X::i’ is private within this context
void g(X x, int ii) {	x.i = ii;  }
//  error: ‘int X::i’ is private within this context
void gg(X * x, int ii) {	x -> i = ii;  }
void Y::f( X * x ) {	x -> i = 100; 	}

class Z {
	int j;
public:
	void initialize();
	void g( X * x );
};

void Z::initialize() { j = 111; }
void Z::g(X * x) { x -> i += j; }

void h() {
	X x;
	x.i = 999;
}

void playWithClasses() {
	X x;
	Y y;
	Z z;
	x.initialize();
	// y.f();
	g(x, 10);
	gg( &x, 10);

	y.f( &x );

	z.initialize();
	z.g( &x );

	h();
}

// _______________________________________________________


// Forward Declaration
class Team;

class Captain {
	// Team team;
	Team * team;
};

class Team {
	Captain captain;
};

/*
https://stackoverflow.com/questions/553682/when-can-i-use-a-forward-declaration

Put yourself in the compiler's position: when you forward declare a type, all the compiler knows is that this type exists; it knows nothing about its size, members, or methods. This is why it's called an incomplete type. Therefore, you cannot use the type to declare a member, or a base class, since the compiler would need to know the layout of the type.

Assuming the following forward declaration.

class X;
Here's what you can and cannot do.

What you can do with an incomplete type:

Declare a member to be a pointer or a reference to the incomplete type:

class Foo {
    X *p;
    X &r;
};
Declare functions or methods which accept/return incomplete types:

void f1(X);
X    f2();
Define functions or methods which accept/return pointers/references to the incomplete type (but without using its members):

void f3(X*, X&) {}
X&   f4()       {}
X*   f5()       {}
What you cannot do with an incomplete type:

Use it as a base class

class Foo : X {} // compiler error!
Use it to declare a member:

class Foo {
    X m; // compiler error!
};
Define functions or methods using this type

void f1(X x) {} // compiler error!
X    f2()    {} // compiler error!
Use its methods or fields, in fact trying to dereference a variable with incomplete type

class Foo {
    X *m;            
    void method()            
    {
        m->someMethod();      // compiler error!
        int i = m->someField; // compiler error!
    }
};

*/

// _______________________________________________________

// Nested Structure
//		Structure Defined Inside Structure
class Handle {
	// Declaration Of Nested Structure
	struct Cheese;
	Cheese * smile;
public:
	void initialize();
	void cleanup();
	int read();
	void change( int );
};
// Definition Of Nested Cheese Structure
struct Handle :: Cheese {
	int i;
};

void Handle::initialize() {
	smile = new Cheese;
	smile -> i = 99;
}

int  Handle::read() { return smile -> i; }
void Handle::change(int x) { smile -> i = x; }
void Handle::cleanup() { delete smile; }

void playWithHandleAndCheese() {
	// Handle :: smile = 100;
	Handle h;
	h.initialize();
	cout << endl;
	cout << "Read Value : " << h.read() << endl;
	h.change( 1000 );
	cout << "Read Value : " << h.read() << endl;
	h.cleanup();
}

// _______________________________________________________

class HandleAgain { // Outer class/struct
	int cheesePackets;
	// Definition Of Nested Cheese Structure
	struct Cheese { // Nested class/struct
		int i;
		int read() { 
			cout << "Cheese read Function Called" << endl;
			return i; 
		}
		void change( int );
		void ship(int packets) {
			// error: invalid use of non-static data member ‘HandleAgain::cheesePackets’
			// 		Nested class/struct Can't Access Outer class/struct Members
			// cheesePackets += packets;
		}
	};

	Cheese smile;
	Cheese * smileReference;
public:
	void initialize();
	void cleanup();
	int read();
	void change( int, int );
	void ship() {
		smile.ship( 10 );
	}
};

void HandleAgain::Cheese::change( int x ) {
	i = x;
	cout << "Cheese change Function Called..." << endl;
}

void HandleAgain::initialize() {
	cheesePackets = 0;
	smile.i = 99;
	smileReference = new Cheese;
	smileReference -> i = 999;
}

int  HandleAgain::read() { return smile.read() + smileReference -> read() ; }
void HandleAgain::change(int x, int y) { 
	cout << "HandleAgain change Function Called..." << endl;
	smile.change( x ) ; 
	smileReference -> change( y ); 
}
void HandleAgain::cleanup() { delete smileReference; }

void playWithHandleAgainAndCheese() {
	// Handle :: smile = 100;
	HandleAgain h;
	h.initialize();
	cout << endl;
	cout << "Read Value : " << h.read() << endl;
	h.change( 100, 1000 );
	cout << "Read Value : " << h.read() << endl;
	h.ship();
	h.cleanup();
}

// _______________________________________________________
// _______________________________________________________

class HandleOnceAgain { // Outer class/struct
	int cheesePackets;
	// Definition Of Nested Cheese Structure
	// friend struct Cheese { //  error: class definition may not be declared a friend
	struct Cheese;
	friend struct Cheese;	
	struct Cheese { // Nested class/struct
		int i;
		HandleOnceAgain *handle;

		int read() { 
			cout << "Cheese read Function Called" << endl;
			return i; 
		}
		void change( int );
		void ship(int packets) {
			// error: invalid use of non-static data member ‘HandleAgain::cheesePackets’
			// 		Nested class/struct Can't Access Outer class/struct Members
			// cheesePackets += packets;
			handle->cheesePackets += packets;
		}
	};

	Cheese smile;
	Cheese * smileReference;
public:
	void initialize();
	void initialize( HandleOnceAgain * );
	void cleanup();
	int read();
	void change( int, int );
	void ship() {
		smile.ship( 10 );
	}
	int getPackets() { return cheesePackets; }
};

void HandleOnceAgain::Cheese::change( int x ) {
	i = x;
	cout << "Cheese change Function Called..." << endl;
}

void HandleOnceAgain::initialize() {
	cheesePackets = 0;
	smile.i = 99;
	smileReference = new Cheese;
	smileReference -> i = 999;
}

void HandleOnceAgain::initialize(HandleOnceAgain *handle) {
	smile.handle = handle;
}

int  HandleOnceAgain::read() { return smile.read() + smileReference -> read() ; }
void HandleOnceAgain::change(int x, int y) { 
	cout << "HandleAgain change Function Called..." << endl;
	smile.change( x ) ; 
	smileReference -> change( y ); 
}
void HandleOnceAgain::cleanup() { delete smileReference; }

void playWithHandleOnceAgainAndCheese() {
	// Handle :: smile = 100;
	HandleOnceAgain h;
	h.initialize();
	cout << endl;
	cout << "Read Value : " << h.read() << endl;
	h.change( 100, 1000 );
	cout << "Read Value : " << h.read() << endl;
	h.initialize( &h );
	h.ship();
	cout << "Get Packets : " << h.getPackets() << endl;

	h.cleanup();
}

// _______________________________________________________
// _______________________________________________________
// _______________________________________________________

int main( int argc, char * argv[] ) {
	cout << "\nFunction : playWithClassAndStructure";
	playWithClassAndStructure();

	cout << "\nFunction : playWithClassBB";
	playWithClassBB();

	cout << "\nFunction : playWithStructuresAAandSB";
	playWithStructuresAAandSB();

	cout << "\nFunction : playWithHandleAndCheese";
	playWithHandleAndCheese();

	cout << "\nFunction : playWithHandleAgainAndCheese";
	playWithHandleAgainAndCheese();

	cout << "\nFunction : playWithHandleOnceAgainAndCheese";
	playWithHandleOnceAgainAndCheese();

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	return 0;
}

