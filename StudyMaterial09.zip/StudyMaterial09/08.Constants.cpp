#include "require.h"
#include <fstream>
#include <string>
#include <iostream>
#include <cassert>
using namespace std;

// _______________________________________________________

void playWithConstants() {
	int a = 20;

	// aptr Is Pointer To Int
	int *aptr = &a;
	cout << endl;
	cout << a << ", " << *aptr << endl;

	a = 30;
	cout << a << ", " << *aptr << endl;

	*aptr = 300;
	cout << a << ", " << *aptr << endl;

	int aa = 200;
	aptr = &aa;
	cout << aa << ", " << *aptr << endl;

	const int b = 20;
	// int *bptr = &b;

	// cptr Is Pointer To Int Which Is Constant
	const int * bptr = &b;

	cout << b << ", " << *bptr << endl;

	// b = 30;  //error: assignment of read-only location 
	// cout << b << ", " << *bptr << endl;

	// *bptr = 300; // error: assignment of read-only location 
	// cout << b << ", " << *bptr << endl;

	int bb = 200;
	bptr = &bb;
	cout << bb << ", " << *bptr << endl;

	bb = 222;
	cout << bb << ", " << *bptr << endl;

	// *bptr = 2222;
	cout << bb << ", " << *bptr << endl;

	const int cc = 100;
	
	// cptr Is Constant Pointer To Int Which Is Constant
	const int * const cptr = &cc;

	// cc = 111;
	// *cptr = 1111;

	const int ccc = 90;
	// cptr = &ccc;

	// *cptr = 99;

	// const int const * ccptr = &cc; // error: duplicate ‘const’
	// ccptr = &ccc;
}

// _______________________________________________________

const int i = 100;
const int j = i + 10;

long address = (long) &j;
char buffer[ j + 10 ];

void playWithConstantsAgain() {
	cout << "\nInput Character : " ;
	const char c = cin.get();
	const char ch = c + 1;

	cout << "Character Ch: " << ch << endl;

	int i[] = { 10, 20, 30, 40 };
	i[0] = 100;

	const int ii[] = { 10, 20, 30, 40 };
	// ii[0] = 100; // error: assignment of read-only location

	struct S { 
		int i, j; 
	};

	S s[] = { {10, 20}, { 100, 200 } };
	s[0].i = 100;

	const S ss[] = { {10, 20}, { 100, 200 } };
	// ss[0].i = 100; // error: assignment of member

	const int * uptr;
	int const * vptr;

	int dd = 100;
	uptr = &dd;
	vptr = &dd;

	dd = 1000;
	// *uptr = 1010;
	// *vptr = 1011;

	int * const vvptr = &dd;
}


// _______________________________________________________


int f3() 		{ return 10; }
const int f4() 	{ return 11; }

void playWithConstReturnValue() {
	const int some  = f3();
	int something 	= f4();

	int a = 10;
	const int b = a;

	const int aa = 10;
	int bb = aa;
}

// _______________________________________________________

class X {
	int i;
public:
	X(int ii = 0);
	void modify();
};

X::X(int ii) { i = ii; }
void X::modify() { i++; }

X f5() {
	return X();
}

const X f6() {
	return X();
}

void f7( X & x ) {
	x.modify();
}

void playWithConstReturnObjects() {
	f5() = X(1);
	f5().modify();

	// f6() = X(1);
	// f6().modify();
}

// _______________________________________________________

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Than Mutability
//		i.e. Whatever Not Suppose To Change Must Be Constant

void t( int * ) {}
void u( const int * cip ) {
	// *cip = 2;
	int i = *cip;
	// int *ip2 = cip;
}

const char * v() { return "Result Of Function v()"; }
const int * const w() {
	static int i;
	return &i;
}

void playWithConstantsArgumentsAndRetunrs() {
	int x = 0;
	int *ip = &x;
	const int * cip = &x;

	t(ip);
	u(ip);
	u(cip);

	const char * ccp = v();
	const int * const ccip = w();
	const int * cip2 = w();

	// char *cp = v();
	// int *ip2 = w();
	// *w() = 1;
} 

// _______________________________________________________

class XX {
	int i;
public:
	XX( int ii );

	// int f();
	int f() const;
	// const int f();
};

XX::XX(int ii) : i(ii) {}
int XX::f() const { return i; }

void playWithConstantMemberFunction() {
	XX x1(10);
	const XX x2(20);
	x1.f();
	x2.f();
}

// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________


int main( int argc, char * argv[] ) {
	cout << "\nFunction : playWithConstants";
	playWithConstants();

	cout << "\nFunction : playWithConstantsAgain";
	playWithConstantsAgain();

	cout << "\nFunction : playWithConstReturnValue";
	playWithConstReturnValue();

	cout << "\nFunction : playWithConstReturnObjects";
	playWithConstReturnObjects();

	cout << "\nFunction : playWithConstantsArgumentsAndRetunrs";
	playWithConstantsArgumentsAndRetunrs();

	cout << "\nFunction : playWithConstantMemberFunction";
	playWithConstantMemberFunction();

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	return 0;
}

