#include "require.h"
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

#define BAND(x) (((x)>5 && (x)<10) ? (x) : 0)

void playWithMacros() {
  ofstream out("macro.out");
  assure(out, "macro.out");
  for(int i = 4; i < 11; i++) {
    int a = i;
    out << "a = " << a << endl << '\t';
    out << "BAND(++a)=" << BAND(++a) << endl;

    // PREPROCESSOR WILL GENERATE FOLLOWING CODE
    //		After Sustituting Macros
    // out << "BAND(++a)=" << (((++a)>5 && (++a)<10) ? (++a) : 0) << endl;
    out << "\t a = " << a << endl;
  }
} ///:~

// _______________________________________________________

class Point {
  int i, j, k;
public:
  Point(): i(0), j(0), k(0) {}
  Point(int ii, int jj, int kk)
    : i(ii), j(jj), k(kk) {}

  // Inline Function By Default    
  void print(const string& msg = "") const {
    if(msg.size() != 0) cout << msg << endl;
    cout << "i = " << i << ", "
         << "j = " << j << ", "
         << "k = " << k << endl;
  }
};

void playWithInlineFunctions() {
  Point p, q(1,2,3);
  p.print("value of p");
  
  // Inline Functions Are Substited  By The Compiler
  // 	At Function Call Location 
// {   // Reference of p will be used inside
//     if(msg.size() != 0) cout << msg << endl;
//     cout << "i = " << i << ", "
//          << "j = " << j << ", "
//          << "k = " << k << endl;
//   }
  q.print("value of q");

  // Inline Functions Are Substited  By The Compiler
  // 	At Function Call Location 

// {
//     if(msg.size() != 0) cout << msg << endl;
//     cout << "i = " << i << ", "
//          << "j = " << j << ", "
//          << "k = " << k << endl;
//   }
} ///:~

// _______________________________________________________

class Rectangle {
  int wide, high;
public:
  Rectangle(int w = 0, int h = 0)
    : wide(w), high(h) {}
  // Accessor Methods i.e. Getter and Setters
  // Good Candidate For Inline Functions
  int width() const { return wide; } // Read
  void width(int w) { wide = w; } // Set
  int height() const { return high; } // Read
  void height(int h) { high = h; } // Set
};

void playWithRectangleInlineFunctions() {
  Rectangle r(19, 47);
  // Change width & height:
  r.height(2 * r.width());
  r.width(2 * r.height());
} ///:~


// _______________________________________________________

class RectangleBetter {
  int width, height;
public:
  RectangleBetter(int w = 0, int h = 0)
    : width(w), height(h) {}

  // Good Naming Conventions For Accessor Methods
  // 	Getter and Setters
  int getWidth() const { return width; }
  void setWidth(int w) { width = w; }
  int getHeight() const { return height; }
  void setHeight(int h) { height = h; }
};

void playWithRectangleBetterInlineFunctions() {
  RectangleBetter r(19, 47);
  // Change width & height:
  r.setHeight(2 * r.getWidth());
  r.setWidth(2 * r.getHeight());
} ///:~

// _______________________________________________________


#include <ctime>
#include <cstring>

class Time {
  std::time_t t;
  std::tm local;
  char asciiRep[26];
  unsigned char lflag, aflag;
  void updateLocal() {
    if(!lflag) {
      local = *std::localtime(&t);
      lflag++;
    }
  }
  void updateAscii() {
    if(!aflag) {
      updateLocal();
      std::strcpy(asciiRep,std::asctime(&local));
      aflag++;
    }
  }
public:
  Time() { mark(); }

//	Examples For Inline Function Candidates
  void mark() {
    lflag = aflag = 0;
    std::time(&t);
  }
  const char* ascii() {
    updateAscii();
    return asciiRep;
  }
  // Difference in seconds:
  int delta(Time* dt) const {
    return int(std::difftime(t, dt->t));
  }
  int daylightSavings() {
    updateLocal();
    return local.tm_isdst;
  }
  int dayOfYear() { // Since January 1
    updateLocal();
    return local.tm_yday;
  }
  int dayOfWeek() { // Since Sunday
    updateLocal();
    return local.tm_wday;
  }
  int since1900() { // Years since 1900
    updateLocal();
    return local.tm_year;
  }
  int month() { // Since January
    updateLocal();
    return local.tm_mon;
  }
  int dayOfMonth() {
    updateLocal();
    return local.tm_mday;
  }
  int hour() { // Since midnight, 24-hour clock
    updateLocal();
    return local.tm_hour;
  }
  int minute() {
    updateLocal();
    return local.tm_min;
  }
  int second() {
    updateLocal();
    return local.tm_sec;
  }
};

void playWithTimeInlineFunctions() {
  Time start;
  for(int i = 1; i < 1000; i++) {
    cout << i << ' ';
    if(i%10 == 0) cout << endl;
  }
  Time end;
  cout << endl;
  cout << "start = " << start.ascii();
  cout << "end = " << end.ascii();
  cout << "delta = " << end.delta(&start);
} ///:~

// _______________________________________________________


class RectangleBetterAgain {
  int width, height;
public:
  RectangleBetterAgain(int w = 0, int h = 0);
  int getWidth() const;
  void setWidth(int w);
  int getHeight() const;
  void setHeight(int h);
};

inline RectangleBetterAgain::RectangleBetterAgain(int w, int h)
  : width(w), height(h) {}

inline int RectangleBetterAgain::getWidth() const {
  return width;
}

inline void RectangleBetterAgain::setWidth(int w) {
  width = w;
}

inline int RectangleBetterAgain::getHeight() const {
  return height;
}

inline void RectangleBetterAgain::setHeight(int h) {
  height = h;
}

void playWithRectangleBetterAgainInlineFunctions() {
  RectangleBetterAgain r(19, 47);
  // Transpose width & height:
  int iHeight = r.getHeight();
  r.setHeight(r.getWidth());
  r.setWidth(iHeight);
} ///:~


// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________



int main( int argc, char * argv[] ) {
	cout << "\nFunction : playWithMacros";
	playWithMacros();

	cout << "\nFunction : playWithInlineFunctions";
	playWithInlineFunctions();

	cout << "\nFunction : playWithRectanngleInlineFunctions";
	playWithRectangleInlineFunctions();

	cout << "\nFunction : playWithRectangleBetterInlineFunctions";
	playWithRectangleBetterInlineFunctions();

	cout << "\nFunction : playWithTimeInlineFunctions";
	playWithTimeInlineFunctions();

	cout << "\nFunction : playWithRectangleBetterAgainInlineFunctions";
	playWithRectangleBetterAgainInlineFunctions();

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	return 0;
}

