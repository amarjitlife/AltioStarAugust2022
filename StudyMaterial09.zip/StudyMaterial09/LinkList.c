#include <stdio.h>
#include <stdlib.h>

// typedef struct item_type {
// 	int data;
// } Item;

typedef struct node_type {
	// Item item;
	int data;
	// Self Referential Structure
	struct node_type *next;
} Node;

Node * createNode( int data ) {
	Node *node = ( Node * ) malloc( sizeof( struct node_type ) );
	node -> data = data;
	node -> next = NULL;

	return node;
}

// Adding Node At The End Of Link List
void addNode( Node * head, Node * node ) {
	// Going Till Last Node
	Node * start = head;
	for(  ; start -> next != NULL ; start = start -> next )
		;
	start -> next = node;
	// Mow Last Node Is node	
}

void printList( Node * head ) {
	// Going Till Last Node
	if ( head == NULL ) {
		printf("\nLink List Is Empty...");
		return;
	}

	Node * start = head;
	for(  ; start != NULL ; start = start -> next ) {
		printf("\nNode Data : %d", start -> data );
	}
}

int main() {
	// Node head  = {   0, NULL };
	// Node node1 = { 100, NULL };
	// Node node2 = { 200, NULL };

	Node * head  = createNode( 0 );
	Node * node1 = createNode( 100 );
	Node * node2 = createNode( 200 );

	// head.next 	= &node1;
	// node1.next 	= &node2;

	addNode( head, node1 );
	addNode( head, node2 );

	// printf("\nNode Data: %d", head -> data );
	// printf("\nNode Data: %d", head -> next -> data );
	// printf("\nNode Data: %d", head -> next -> next -> data );
	// printf("\nNode Next: %p", head -> next -> next -> next );

	printList( head );
}

// https://codebunk.com/b/7101100514205/
// https://codebunk.com/b/7101100514205/
// https://codebunk.com/b/7101100514205/


