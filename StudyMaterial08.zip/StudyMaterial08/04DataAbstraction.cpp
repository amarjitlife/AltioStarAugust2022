
#include "require.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cassert>

using namespace std;

// _______________________________________________________
// _______________________________________________________

struct  A {
	int i[100];
	void f();
};

struct B {
	void f();
};

void A::f() { cout << "A::f Function Called" << endl; }
void B::f() { cout << "B::f Function Called" << endl; }

void playWithStructAandB() {
	A aObject;
	B bObject;

	cout << endl;
	cout << aObject.i << endl; 
	aObject.f();

	bObject.f();
}

// _______________________________________________________

class AA {
public:
	int i[100];
	void f();
};

class BB {
public:
	void f();
};

void AA::f() { cout << "AA::f Function Called" << endl; }
void BB::f() { cout << "BB::f Function Called" << endl; }

void playWithClassAAandBB() {
	AA aObject;
	BB bObject;

	cout << endl;
	cout << aObject.i << endl; 
	aObject.f();

	bObject.f();
}

// _______________________________________________________

typedef struct CStashSize {
	int size;      // Size of each space
	int quantity;  // Number of storage spaces
	int next;      // Next empty space
	int something;
	char ch;
	// Dynamically allocated array of bytes:
	unsigned char* storage;
} CStashSize;

struct StashSize {
	int size;      // Size of each space
	int quantity;  // Number of storage spaces
	int next;      // Next empty space
	int something;
	char ch;

	 // Dynamically allocated array of bytes:
	unsigned char* storage;
	// Functions!
	void initialize(int size);
	void cleanup();
	int add(const void* element);
	void* fetch(int index);
	int count();
	void inflate(int increase);
}; ///:~


void playWithStructAndClassSizeOf() {
	cout << endl;

	cout << "A Sizeof :" << sizeof( A ) << endl;
	cout << "B Sizeof :" << sizeof( B ) << endl;

	cout << "AA Sizeof :" << sizeof( AA ) << endl;
	cout << "BB Sizeof :" << sizeof( BB ) << endl;

	cout << "CStash Sizeof :" << sizeof( CStashSize ) << endl;
	cout << "Stash Sizeof :"  << sizeof( StashSize ) << endl;
}


// _______________________________________________________
// _______________________________________________________


// 
typedef struct CStashTag {
	int size;      // Size of each space
	int quantity;  // Number of storage spaces
	int next;      // Next empty space
	// Dynamically allocated array of bytes:
	unsigned char* storage;
} CStash;

void initialize(CStash* s, int size);

void cleanup(CStash* s);
int add(CStash* s, const void* element);
void* fetch(CStash* s, int index);
int count(CStash* s);
void inflate(CStash* s, int increase);


// Quantity of elements to add
// when increasing storage:
const int increment = 100;

void initialize(CStash* s, int sz) {
	s->size = sz;
	s->quantity = 0;
	s->storage = 0;
	s->next = 0;
}

int add(CStash* s, const void* element) {
	if(s->next >= s->quantity) //Enough space left?
		inflate(s, increment);
	// Copy element into storage,
	// starting at next empty space:
	int startBytes = s->next * s->size;
	unsigned char* e = (unsigned char*)element;
	for(int i = 0; i < s->size; i++)
		s->storage[startBytes + i] = e[i];
	s->next++;
	return(s->next - 1); // Index number
}

void* fetch(CStash* s, int index) {
	// Check index boundaries:
	assert(0 <= index);
	if(index >= s->next)
		return 0; // To indicate the end
	// Produce pointer to desired element:
	return &(s->storage[index * s->size]);
}

int count(CStash* s) {
	return s->next;  // Elements in CStash
}

void inflate(CStash* s, int increase) {
	assert(increase > 0);
	int newQuantity = s->quantity + increase;
	int newBytes = newQuantity * s->size;
	int oldBytes = s->quantity * s->size;
	unsigned char* b = new unsigned char[newBytes];
	for(int i = 0; i < oldBytes; i++)
		b[i] = s->storage[i]; // Copy old to new
	delete [](s->storage); // Old storage
	s->storage = b; // Point to new memory
	s->quantity = newQuantity;
}

void cleanup(CStash* s) {
	if(s->storage != 0) {
	 cout << "freeing storage" << endl;
	 delete []s->storage;
	}
} 

void playWithCStash() {
	// Define variables at the beginning
	// of the block, as in C:
	CStash intStash, stringStash;
	int i;
	char* cp;
	ifstream in;
	string line;
	const int bufsize = 10;
	// Now remember to initialize the variables:
	initialize(&intStash, sizeof(int));
	for(i = 0; i < 100; i++)
		add(&intStash, &i);
	for(i = 0; i < count(&intStash); i++)
		cout << "fetch(&intStash, " << i << ") = "
				 << *(int*)fetch(&intStash, i)
				 << endl;
	// Holds 80-character strings:
	initialize(&stringStash, sizeof(char)*bufsize);
	in.open("someFile.txt");
	assert(in);
	while(getline(in, line))
		add(&stringStash, line.c_str());
	i = 0;
	while((cp = (char*)fetch(&stringStash,i++))!=0)
		cout << "fetch(&stringStash, " << i << ") = "
				 << cp << endl;
	cleanup(&intStash);
	cleanup(&stringStash);
} ///:~

// _______________________________________________________
// _______________________________________________________

struct Stash {
	int size;      // Size of each space
	int quantity;  // Number of storage spaces
	int next;      // Next empty space
	 // Dynamically allocated array of bytes:
	unsigned char* storage;
	// Functions!
	void initialize(int size);
	void cleanup();
	int add(const void* element);
	void* fetch(int index);
	int count();
	void inflate(int increase);
}; ///:~


// const int increment = 100;

void Stash::initialize(int sz) {
	size = sz;
	quantity = 0;
	storage = 0;
	next = 0;
}

int Stash::add(const void* element) {
	if(next >= quantity) // Enough space left?
		inflate(increment);
	// Copy element into storage,
	// starting at next empty space:
	int startBytes = next * size;
	unsigned char* e = (unsigned char*)element;
	for(int i = 0; i < size; i++)
		storage[startBytes + i] = e[i];
	next++;
	return(next - 1); // Index number
}

void* Stash::fetch(int index) {
	// Check index boundaries:
	assert(0 <= index);
	if(index >= next)
		return 0; // To indicate the end
	// Produce pointer to desired element:
	return &(storage[index * size]);
}

int Stash::count() {
	return next; // Number of elements in CStash
}

void Stash::inflate(int increase) {
	assert(increase > 0);
	int newQuantity = quantity + increase;
	int newBytes = newQuantity * size;
	int oldBytes = quantity * size;
	unsigned char * b = new unsigned char[newBytes];
	for(int i = 0; i < oldBytes; i++)
		b[i] = storage[i]; // Copy old to new
	delete []storage; // Old storage
	storage = b; // Point to new memory
	quantity = newQuantity;
}

void Stash::cleanup() {
	if(storage != 0) {
		cout << "freeing storage" << endl;
		delete []storage;
	}
} ///:~

void playWithStash() {
	Stash intStash;
	intStash.initialize(sizeof(int));
	for(int i = 0; i < 10; i++)
		intStash.add(&i);
	for(int j = 0; j < intStash.count(); j++)
		cout << "intStash.fetch(" << j << ") = "
				 << *(int*)intStash.fetch(j)
				 << endl;
	// Holds 80-character strings:
	Stash stringStash;
	const int bufsize = 10;
	stringStash.initialize(sizeof(char) * bufsize);
	ifstream in("someFile.txt");
	assure(in, "someFile.txt");
	string line;
	while(getline(in, line))
		stringStash.add(line.c_str());
	int k = 0;
	char* cp;
	while((cp =(char*)stringStash.fetch(k++)) != 0)
		cout << "stringStash.fetch(" << k << ") = "
				 << cp << endl;
	intStash.cleanup();
	stringStash.cleanup();
} ///:~

// _______________________________________________________

int a;
void f() { cout << "f Function Called..." << endl; }

struct Some {
	int a;
	void f();
};

void Some::f() {
	::f();
	// f();
	::a++;
	a--;
}

void playWithScopeOperator() {
	Some s1;
	Some * s2 = new Some(); 	
	f();
	cout << "a Value: " << a << endl;

	s1.f();
	s2->f();
	cout << "a Value: " << s1.a << endl;
	cout << "a Value: " << s2->a << endl;
}

// _______________________________________________________

#include "require.h"
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

struct Stack {
	struct Link {
		void* data;
		Link* next;
		void initialize(void* dat, Link* nxt);
	}* head;
	void initialize();
	void push(void* dat);
	void* peek();
	void* pop();
	void cleanup();
};

void 
Stack::Link::initialize(void* dat, Link* nxt) {
	data = dat;
	next = nxt;
}

void Stack::initialize() { head = 0; }

void Stack::push(void* dat) {
	Link* newLink = new Link;
	newLink->initialize(dat, head);
	head = newLink;
}

void* Stack::peek() { 
	require(head != 0, "Stack empty");
	return head->data; 
}

void* Stack::pop() {
	if(head == 0) return 0;
	void* result = head->data;
	Link* oldHead = head;
	head = head->next;
	delete oldHead;
	return result;
}

void Stack::cleanup() {
	require(head == 0, "Stack not empty");
} ///:~


void playWithStack(int argc, char *argv[]) {
	requireArgs(argc, 1); // File name is argument
	ifstream in(argv[1]);
	assure(in, argv[1]);
	Stack textlines;
	textlines.initialize();
	string line;
	// Read file and store lines in the Stack:
	while(getline(in, line))
		textlines.push(new string(line));
	// Pop the lines from the Stack and print them:
	string* s;
	while((s = (string*)textlines.pop()) != 0) {
		cout << *s << endl;
		delete s; 
	}
	textlines.cleanup();
} ///:~


// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________

int main( int argc, char * argv[] ) {
	cout << "\nFunction : playWithStructAandB";
	playWithStructAandB();

	cout << "\nFunction : playWithClassAAandBB";
	playWithClassAAandBB();

	cout << "\nFunction : playWithStructAndClassSizeOf";
	playWithStructAndClassSizeOf();

	cout << "\nFunction : playWithCStash";
	playWithCStash();

	cout << "\nFunction : playWithStash";
	playWithStash();

	cout << "\nFunction : playWithScopeOperator";
	playWithScopeOperator();

	cout << "\nFunction : playWithStack";
	playWithStack(argc, argv);

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	return 0;
}

