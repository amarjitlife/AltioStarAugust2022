#include <string>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

// _______________________________________________________
// _______________________________________________________


// Declaration Of Identifier sum
// Function Prototype
int sum(int x, int y) ;


// sum Identifier Definition
int sum(int x, int y) {
	// Code Here...
	return 0;
}

// _______________________________________________________
// _______________________________________________________

void helloWorld() {
	cout << "\nHello, World! I am " << 18 << " Today!" << endl;
}

// _____________________________________________

void playWithDataConversion() {
	cout << endl;

	cout << "A Number In Decimal(Base 10): " << 15 << endl;
	cout << "A Number In Octal ( Base 8) : " << oct << 15 << endl;
	cout << "A Number In Hex ( Base 16) : " << hex << 15 << endl;

	cout << "Floating Point Number : " << 3.14159 << endl;
	// cout << "Non Printing Character (Esc) : " << char(27) << endl;

	// Concatinate The Strings
	cout << "Hello World!"
			"Ding Dong"
			"Ting Tong" << endl;
}


// _______________________________________________________
// _______________________________________________________

void playWithDataInput() {
	int number;

	cout << endl <<"Enter Number In Decimal: ";
	cin >> number;
	cout << "Value In Octal = 0" << oct << number << endl;
	cout << "Value In Octal = 0x" << hex << number << endl;
}


// _______________________________________________________
// _______________________________________________________

void playWithStrings() {
	string s1, s2;
	cout << s1 << s2 << endl;

	string s3 = "Hello, World!";
	string s4("Some String Value");

	cout << s3 << endl << s4 << endl;

	// String Concatenation
	s1 = s3 + " " + s4;
	s1 += " Ding Dong ";

	cout << s1 + s2 + "!" << endl;
}


// _______________________________________________________
// _______________________________________________________

void playWithStreams() {
	int lineCount = 1;
	ifstream in("someFile.txt");
	ofstream out("someFileAgain.txt");
	string line;

	cout << endl;
	while( getline(in, line) ) {
		cout << lineCount << "." << line << "\n";
		lineCount++;
	}

	ifstream inAgain("someFile.txt");
	lineCount = 1;
	while( getline(inAgain, line) ) {
		out << lineCount << "." << line << "\n";
		lineCount++;
	}

	ifstream inOnceAgain("someFile.txt");
	string s = "";
	lineCount = 1;
	while( getline(inOnceAgain, line) ) {
		s += lineCount + "." + line + "\n";
		lineCount++;
		// cout << "Check : " << line << endl;
	}

	cout << "\nFile Buffer" << endl;
	cout << s << endl;
}


// _______________________________________________________
// _______________________________________________________


void playWithStringVector() {
	vector<string> data;
	ifstream in("someFile.txt");

	string line;

	while( getline( in, line )) {
		data.push_back( line );
	}

	cout << endl;
	for( int i = 0 ; i < data.size() ; i++ ) {
		cout << i + 1 << " : " << data[i] << endl;
	}
}


// _______________________________________________________
// _______________________________________________________

void playWithTypeChecks() {
	string s = "Good Morning!!!";
	int i = 100;

	// Compilation Error Due To Type Checking
	// i = s ;
}


// _______________________________________________________
// _______________________________________________________

void playWithWordsCount() {
	vector <string> words;

	ifstream in("someFile.txt");
	string word;

	while ( in >> word ) {
		words.push_back( word );
	}

	for( int i = 0 ; i < words.size() ; i++ ) {
		cout << words[i] << endl;
	}

	cout << "\nWords Count: " << words.size();
}

// C1: Coding Assignment
//		Improve playWithWordsCount Code Example To Count Frequency Of Words
//		Print Word and It's Frequency

// _______________________________________________________
// _______________________________________________________

void playWithIntVector() {
	int number = 2;
	vector <int> twoTable;

	// Creating Number's Table
	for( int i = 1 ; i <= 10 ; i++ ) {
		twoTable.push_back( 2 * i ) ;
	}

	cout << endl;
	for( int i = 0 ; i <= 9 ; i++ ) {
		cout << number << " * " << i + 1  << " = " << dec << twoTable[i] << endl ;
	}
}

// C2: Coding Assignment
//		Improve playWithIntVector Code Example To 
//		To Generate Tables From M To N Integer (Inclusive)

// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________
// _______________________________________________________

// error: ‘::main’ must return ‘int’
//void main() {
int main() {
	cout << "\nFunction : helloWorld";
	helloWorld();

	cout << "\nFunction : playWithDataConversion";
	playWithDataConversion();

	// cout << "\nFunction : playWithDataInput";
	// playWithDataInput();

	cout << "\nFunction : playWithStrings";
	playWithStrings();

	cout << "\nFunction : playWithStreams";
	playWithStreams();

	cout << "\nFunction : playWithStringVector";
	playWithStringVector();

	cout << "\nFunction : playWithTypeChecks";
	playWithTypeChecks();

	cout << "\nFunction : playWithWordsCount";
	playWithWordsCount();

	cout << "\nFunction : playWithIntVector";
	playWithIntVector();

	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";
	// cout << "\nFunction : ";

	return 0;
}

