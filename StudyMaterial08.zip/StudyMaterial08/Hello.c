
#include <stdio.h>

int main() {
	char greeting[20] = "Hello World!";
	printf("\n Greeting : %s", greeting ); 
}

