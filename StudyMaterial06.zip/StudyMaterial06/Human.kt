
package learnKotlin

// Communication Protocol
// What It WIll Do!
interface Superpower {
	fun fly()
	fun saveWorld()
}

// How, When, Where, Which Way It Will Do
open class Heman {
	open fun fly() 		{ println("Fly Like Spiderman!") }
	open fun saveWorld() { println("Save World Like Spiderman!") }
}

class Spiderman : Superpower {
	override fun fly() 		{ println("Fly Like Spiderman!") }
	override fun saveWorld() { println("Save World Like Spiderman!") }
}

class Superman : Superpower {
	override fun fly() 		 { println("Fly Like Superman!") }
	override fun saveWorld() { println("Save World Like Superman!") }
}

class Wonderwoman : Superpower {
	override fun fly() 		 { println("Fly Like Wonderwoman!") }
	override fun saveWorld() { println("Save World Like Wonderwoman!") }
}

// Using Inheritance
class HumanDesign1: Heman() {
	override fun fly() 		 { super.fly() 		 }
	override fun saveWorld() { super.saveWorld() }
}

// Using Composition
class HumanDesign2 {
	var power : Superpower? = null
	fun fly() 		 { power?.fly() 		 }
	fun saveWorld()  { power?.saveWorld() }
}

fun main() {
	println("... HUMAN DESIGN 1 ... ")
	var human = HumanDesign1()
	human.fly()
	human.saveWorld()

	println("... SPIDERMAN ... ")
	var spiderman = Spiderman()
	spiderman.fly()
	spiderman.saveWorld()

	println("... HUMAN DESIGN 2 ... ")
	var humanAgain = HumanDesign2()
	humanAgain.power = Spiderman()
	humanAgain.fly()
	humanAgain.saveWorld()

	humanAgain.power = Superman()
	humanAgain.fly()
	humanAgain.saveWorld()

	humanAgain.power = Wonderwoman()
	humanAgain.fly()
	humanAgain.saveWorld()
}

