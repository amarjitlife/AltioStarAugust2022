
#include <stdio.h>

typedef struct human_type {
	int id;
	char name[20];
	void (*dance)();

} Human;

void doBhangra() {
	printf("\nBallleeee Balleeee");
}

void doBharatnatayam() {
	printf("\nEyes and Hands Moment...");
}

void playWithHuman() {
				 // Constructor
	Human gabbar = { 101, "Gabbar Singh", doBhangra };

	printf("\nID: 	%d", gabbar.id );
	printf("\nName: %s", gabbar.name );

	gabbar.dance();
				 // Constructor
	Human sudha = { 111, "Sudha Chandra", doBharatnatayam };

	printf("\nID: 	%d", sudha.id );
	printf("\nName: %s", sudha.name );

	sudha.dance();
}

int main() {
	playWithHuman();
}
